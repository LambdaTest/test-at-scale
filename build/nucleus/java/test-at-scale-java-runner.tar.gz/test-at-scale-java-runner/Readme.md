# test-at-scale-java-runner

Custom runners written on top of javascript testing frameworks. For
running [Test-at-scale](https://www.lambdatest.com/test-at-scale) locally,
follow [this](https://github.com/LambdaTest/test-at-scale).

## Building From Source

test-at-scale-java-runner requires Apache Maven 3.x. To build from source and install to your local Maven repository,
execute the following:

```sh
mvn install
```

## Local Testing

### Configuring Maven Extension for Manipulating pom.xml

You can use either of these methods to configure the
maven extension.

- Add your extension jar in ${maven.home}/lib/ext.
- Add it as a build extension in the pom in the target repository.

```  xml
<build>
  ...
  <extensions>
  ...
  <extension>
  <groupId>com.lambdatest</groupId>
  <artifactId>ext</artifactId>
  <version>1.0-SNAPSHOT</version>
  </extension>
  ...
  </extensions>
  ...
  </build>
```

- (since Maven 3.3.1) Configure the extension in .mvn/extensions.xml in the target repository.

```xml

<extensions xmlns="http://maven.apache.org/EXTENSIONS/1.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xsi:schemaLocation="http://maven.apache.org/EXTENSIONS/1.0.0 http://maven.apache.org/xsd/core-extensions-1.0.0.xsd">
    <extension>
        <groupId>com.lambdatest</groupId>
        <artifactId>ext</artifactId>
        <version>1.0-SNAPSHOT</version>
    </extension>
</extensions>

```

### Deprecated: Adding Manually Provider In Target Repository

The following example shows how to force usage of the JUnit 4 provider:

```xml

<plugins>
    [...]
    <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-surefire-plugin</artifactId>
        <version>2.22.0</version>
        <dependencies>
            <dependency>
                <groupId>com.lambdatest.surefire-2.22</groupId>
                <artifactId>junit4</artifactId>
                <version>1.0-SNAPSHOT</version>
            </dependency>
        </dependencies>
    </plugin>
    [...]
</plugins>
```

**Note:** The minimum supported surefire version is `2.19.1`

### Run Test Discovery and Execution with Maven

```sh
 mvn test -Dmode=discover -DfailIfNoTests=false # discovery
 mvn test -Dmode=execute                        # execution
```