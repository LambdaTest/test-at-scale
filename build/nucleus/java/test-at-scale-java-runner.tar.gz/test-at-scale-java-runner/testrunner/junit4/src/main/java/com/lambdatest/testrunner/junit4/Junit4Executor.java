package com.lambdatest.testrunner.junit4;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.request.RequestUtils;
import org.junit.Ignore;
import org.junit.internal.runners.ErrorReportingRunner;
import org.junit.runner.*;
import org.junit.runner.manipulation.Filter;
import org.junit.runner.notification.RunListener;
import org.junit.runner.notification.RunNotifier;

import java.util.*;

import static com.lambdatest.testrunner.junit4.Junit4Helper.createSuite;
import static com.lambdatest.testrunner.junit4.Junit4Helper.createTest;
import static org.junit.runner.Description.TEST_MECHANISM;

public class Junit4Executor {

    private final Logger logger;

    private final RequestUtils request;

    private final Collection<TestObject> tests;

    private final Collection<TestSuiteObject> suites;

    private final Collection<TestExecutionObject> testResults;
    private final Collection<TestSuiteExecutionObject> testSuiteResults;

    public Junit4Executor(Logger logger) {
        this.request = new RequestUtils(logger);
        this.logger = logger;
        this.tests = new ArrayList<>();
        this.suites = new ArrayList<>();
        this.testResults = new ArrayList<>();
        this.testSuiteResults = new ArrayList<>();
    }

    public void discover(Iterable<Class<?>> testClasses,
                         Filter filter) throws RuntimeException {

        for (Class<?> testToRun : testClasses) {
            logger.info("Discovering" + testToRun.getName() + "\n");
            if (testToRun.isAnnotationPresent(Ignore.class)) {
                logger.info("Ignoring class " + testToRun.getName() + "\n");
                continue;
            }
            Request request = Request.aClass(testToRun);
            if (filter != null) {
                request = request.filterWith(filter);
            }
            Runner runner = request.getRunner();
            if (!(runner instanceof ErrorReportingRunner)) {
                Integer testCount = findTestsInRunner(request.getRunner().getDescription(), tests, suites);
                if (testCount == 0) {
                    throw new RuntimeException("Failed to find tests for class " + testToRun.getName());
                }
            } else {
                // exact error not captured
                throw new RuntimeException("Error while discovering class " + testToRun.getName());
            }
        }
        request.sendDiscoveryResult(tests, suites);
    }

    public void execute(RunListener listener,
                        Iterable<Class<?>> testClasses,
                        Filter filter
    ) throws RuntimeException {
//
        final RunNotifier runNotifier = getRunNotifier(listener);
        try {
            for (Class<?> testToRun : testClasses) {
                createRequestAndRun(testToRun, runNotifier, filter);
            }
        } finally {
            runNotifier.removeListener(listener);
        }
        request.sendExecutionResult(testResults, testSuiteResults);
    }

    private int findTestsInRunner(Description description,
                                  Collection<TestObject> testCases,
                                  Collection<TestSuiteObject> testSuites) {
        final Deque<Description> nodeStack = new ArrayDeque<>();
        final Deque<Integer> indexStack = new ArrayDeque();
        final Map<String, Integer> suiteTestCount = new HashMap<>();
        int totalCount = 0;
        Description currentNode = description;
        int currentIndex = 0;
        while (currentNode != null) {
            if (currentNode.isSuite()) {
                TestSuiteObject testSuite = createSuite(currentNode);
                testSuites.add(testSuite);
            }
            // Move down to first child, if exists
            if (!currentNode.getChildren().isEmpty()) {
                nodeStack.push(currentNode);
                indexStack.push(currentIndex);
                currentIndex = 0;
                currentNode = currentNode.getChildren().get(0);
                continue;
            }
            do {

                // can be null if @Ignore annotation present on test suite.
                if (currentNode.isTest() && currentNode.getMethodName() != null) {
                    TestObject test = createTest(currentNode);
                    String testSuiteID = test.getSuiteID();
                    totalCount++;
                    testCases.add(test);
                    suiteTestCount.merge(testSuiteID, 1, Integer::sum);

                }
                // No parent, so no siblings
                if (nodeStack.isEmpty()) {
                    currentNode = null;
                    currentIndex = 0;
                    break;
                }

                // Move to next sibling if possible
                if (nodeStack.peek().getChildren().size() > ++currentIndex) {
                    currentNode = nodeStack.peek().getChildren().get(currentIndex);
                    break;
                }

                // No next, sibling, so move up
                currentNode = nodeStack.pop();
                currentIndex = indexStack.pop();
            } while (currentNode != null);
        }
        for (TestSuiteObject testSuite : testSuites) {
            Integer suiteCount = suiteTestCount.get(testSuite.getSuiteID());
            if (suiteCount != null) {
                testSuite.setTotalTests(suiteCount);
            }
        }
        return totalCount;
    }

    private static boolean hasFilteredOutAllChildren(Description description) {
        if (isFailureInsideJUnitItself(description)) {
            return true;
        }
        String name = description.getDisplayName();
        // JUnit 4.0: initializationError0; JUnit 4.12: initializationError.
        if (name == null) {
            return true;
        } else {
            name = name.trim();
            return name.startsWith("initializationError0(org.junit.runner.manipulation.Filter)") || name.startsWith("initializationError(org.junit.runner.manipulation.Filter)");
        }
    }

    private void createRequestAndRun(Class<?> classToRun, RunNotifier notifier, Filter filter) throws RuntimeException {
        Request req = Request.aClass(classToRun);
        if (req.getRunner() == null) {
            // nothing to run
            return;
        }
        if (filter != null) {
            req = req.filterWith(filter);
        }
        Result result = new Result();
        RunListener resultListener = result.createListener();
        notifier.addFirstListener(resultListener);

        Runner runner = req.getRunner();
        try {
            notifier.fireTestRunStarted(runner.getDescription());
            runner.run(notifier);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
            notifier.fireTestRunFinished(result);
            notifier.removeListener(resultListener);
        }
    }

    public Collection<TestExecutionObject> getTestResults() {
        return this.testResults;
    }

    public Collection<TestSuiteExecutionObject> getSuiteResults() {
        return this.testSuiteResults;
    }

    private RunNotifier getRunNotifier(RunListener main) {
        RunNotifier notifier = new RunNotifier();
        notifier.addListener(main);
        return notifier;
    }

    private static boolean isFailureInsideJUnitItself(Description failure) {
        return TEST_MECHANISM.equals(failure);
    }


}
