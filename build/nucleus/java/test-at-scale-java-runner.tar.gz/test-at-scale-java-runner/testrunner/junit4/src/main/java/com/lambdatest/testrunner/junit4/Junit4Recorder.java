package com.lambdatest.testrunner.junit4;

import com.lambdatest.runner.api.models.Status;
import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import org.junit.runner.Description;
import org.junit.runner.notification.Failure;

import java.time.Instant;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import static com.lambdatest.testrunner.junit4.Junit4Helper.createSuiteResult;
import static com.lambdatest.testrunner.junit4.Junit4Helper.createTestResult;

public class Junit4Recorder {

    private Description currentTestSetDescription;
    private TestExecutionObject currentTest;

    private Long currentTestStartTime;
    private final Collection<TestExecutionObject> testResults;
    private final Collection<TestSuiteExecutionObject> suiteResults;
    private final Map<String, TestSuiteExecutionObject> suiteTest = new HashMap<>();


    public Junit4Recorder(Collection<TestExecutionObject> testResults,
                          Collection<TestSuiteExecutionObject> suiteResult) {
        this.testResults = testResults;
        this.suiteResults = suiteResult;
    }

    public void markTestStarted(Description description) {
        currentTest = createTestResult(description);
        currentTestStartTime = System.currentTimeMillis();
        currentTest.setStart_time(Instant.ofEpochMilli(currentTestStartTime).toString());
    }

    public void markTestIgnored(Description description) {
        if (description.getMethodName() != null) {
            currentTest = createTestResult(description);
            currentTest.setStatus(Status.skipped);
            testResults.add(currentTest);
            createOrUpdateSuite(description, currentTest);
        }
    }

    public void markTestFailed(Failure failure) {
        currentTest.setStatus(Status.failed);
        currentTest.setFailureMessage(failure.getMessage());
    }


    public void markTestFinished(Description description) {
        Long testEndTime = System.currentTimeMillis();
        currentTest.setEnd_time(Instant.ofEpochMilli(testEndTime).toString());
        long testRunTime = testEndTime - currentTestStartTime;
        currentTest.setDuration(testRunTime);
        if (currentTest.getStatus() == null) {
            currentTest.setStatus(Status.passed);
        }
        testResults.add(currentTest);
        createOrUpdateSuite(description, currentTest);

    }

    private void createOrUpdateSuite(Description description, TestExecutionObject test) {
        String suiteID = test.getSuiteID();
        TestSuiteExecutionObject suite = suiteTest.get(suiteID);
        if (suite == null) {
            suite = createSuiteResult(description, suiteID);
            updateSuite(suite, currentTest);
            suiteTest.put(suiteID, suite);
        } else {
            updateSuite(suite, currentTest);
        }
    }

    private void updateSuite(TestSuiteExecutionObject suite, TestExecutionObject test) {
        suite.setDuration(suite.getDuration() + test.getDuration());
        suite.setTotalExecutedTests(suite.getTotalExecutedTests() + 1);
        // set the start time of the first test as the start  time of test
        if (suite.getStart_time() == null) {
            suite.setStart_time(test.getStart_time());
        }
        switch (test.getStatus()) {
            case passed:
                suite.setTotalTestsPassed(suite.getTotalTestsPassed() + 1);
                break;
            case failed:
                suite.setTotalTestsFailed(suite.getTotalTestsFailed() + 1);
                break;
            case skipped:
                suite.setTotalTestsSkipped(suite.getTotalTestsSkipped() + 1);
        }
    }

    public void markTestRunFinished() {
        // record all suites when testRunFinished
        suiteTest.forEach((k, v) -> {
            Instant i = Instant.parse(v.getStart_time()).plusMillis(v.getDuration());
            v.setEnd_time(i.toString());
            // calculate winner status
            v.setStatus(v.winnerSuiteStatus());
            suiteResults.add(v);
        });
        // clear map
        suiteTest.clear();

    }

    public void setCurrentTestSetDescription(Description description) {
        currentTestSetDescription = description;
    }

    public boolean describesNewTestSet(Description description) {
        if (currentTestSetDescription != null) {
            if (null != description.getTestClass()) {
                return !description.getTestClass().equals(currentTestSetDescription.getTestClass());
            } else if (description.isSuite()) {
                return description.getChildren().equals(currentTestSetDescription.getChildren());
            }
            return false;
        }
        return true;
    }
}
