package com.lambdatest.testrunner.junit4;

import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.util.MD5;
import org.junit.runner.Description;

import java.nio.file.Path;
import java.nio.file.Paths;

import static com.lambdatest.runner.api.util.Utils.*;

class Junit4Helper {

    private static final Path currentDirectory = Paths.get(System.getProperty("user.dir"));

    public static TestSuiteObject createSuite(Description suiteDescription) {
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                suiteDescription.getDisplayName()));
        String className = suiteDescription.getClassName();
        String filePath = fullQualifiedNameToPath(suiteDescription.getClassName());
        String suiteModifiedClassName = className + String.format(" (%s)",filePath);
        return TestSuiteObject.builder().suiteID(suiteID)
                .locator(String.join(LocatorDelimiter, filePath, className))
                .suiteName(suiteModifiedClassName).build();
    }

    public static TestObject createTest(Description testDescription) {
        String filePath = fullQualifiedNameToPath(testDescription.getClassName());
        String methodName = testDescription.getMethodName();
        String className = testDescription.getClassName();
        String testID = MD5.getMd5(String.join("\n", RepoID,
                className, methodName));
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));

        return TestObject.builder().testID(
                        testID
                ).title(
                        testDescription.getDisplayName()
                ).testName(
                        methodName
                ).className(
                        className
                ).filepath(
                        filePath
                ).locator(String.join(LocatorDelimiter,
                        filePath, className, methodName))
                .suiteID(suiteID)
                .build();
    }

    public static TestExecutionObject createTestResult(Description testDescription) {
        String filePath = fullQualifiedNameToPath(testDescription.getClassName());
        String methodName = testDescription.getMethodName();
        String className = testDescription.getClassName();
        String testID = MD5.getMd5(String.join("\n", RepoID,
                className, methodName));
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));

        return TestExecutionObject.childBuilder().testID(
                        testID
                ).testName(
                        methodName
                ).className(
                        className
                ).locator(String.join(LocatorDelimiter,
                        filePath, className, methodName))
                .suiteID(suiteID)
                .build();
    }

    public static TestSuiteExecutionObject createSuiteResult(Description suiteDescription, String suiteID) {
        String className = suiteDescription.getClassName();
        String filePath = fullQualifiedNameToPath(suiteDescription.getClassName());
        String suiteModifiedClassName = className + String.format(" (%s)",filePath);
        return TestSuiteExecutionObject.childBuilder().suiteID(suiteID)
                .suiteName(suiteModifiedClassName)
                .locator(String.join(LocatorDelimiter,
                        filePath, className)).build();
    }
}
