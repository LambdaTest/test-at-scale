package com.lambdatest.testrunner.testng.conf;


import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlSuite;

/**
 * Configurator for passing configuration properties to TestNG
 */
public interface Configurator {
    void configure(TestNG testng, Map<String, String> options)
            throws RuntimeException;

    void configure(XmlSuite suite, Map<String, String> options)
            throws RuntimeException;
}
