package com.lambdatest.testrunner.testng.conf;


/**
 * TestNG 5.14.1 configurator. Changed: "listener" use List instead of String.
 */
public class TestNG5141Configurator
    extends TestNG513Configurator
{

    @Override
    protected Object convertListeners( String listenerClasses ) throws RuntimeException
    {
        // TODO "configure(CommandLineArgs)", which should replace "configure(Map)", doesn't have the issue
        throw new RuntimeException( "Due to an internal TestNG issue, "
                                          + "the listener feature of TestNG is not supported with 5.14.1 and 5.14.2" );
    }
}
