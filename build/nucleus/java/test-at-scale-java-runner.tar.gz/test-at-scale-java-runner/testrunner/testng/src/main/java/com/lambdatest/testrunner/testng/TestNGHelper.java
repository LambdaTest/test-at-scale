package com.lambdatest.testrunner.testng;

import com.lambdatest.runner.api.models.*;
import com.lambdatest.runner.api.util.MD5;
import org.apache.commons.lang3.StringUtils;
import org.testng.IClass;
import org.testng.ITestResult;

import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Arrays;
import java.util.stream.Collectors;

import static com.lambdatest.runner.api.util.Utils.*;

public class TestNGHelper {
    private static final Path currentDirectory = Paths.get(System.getProperty("user.dir"));

    public static TestSuiteObject createSuite(Class<?> testClass) {
        String className = testClass.getName();
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));
        String filePath = fullQualifiedNameToPath(className);
        return TestSuiteObject.builder().suiteID(suiteID)
                .locator(String.join(LocatorDelimiter, filePath, className))
                .suiteName(className).build();
    }

    public static TestObject createTest(Method testMethod) {
        String className = testMethod.getDeclaringClass().getName();
        String methodName = testMethod.getName();
        String filePath = fullQualifiedNameToPath(className);
        String methodNameWithParams = getTestMethodNameWithParameters(testMethod);
        String testID = MD5.getMd5(String.join("\n", RepoID,
                className, methodNameWithParams));
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));

        return TestObject.builder().testID(
                        testID
                ).title(
                        methodNameWithParams
                ).testName(
                        methodNameWithParams
                ).className(
                        className
                ).filepath(
                        filePath
                ).locator(String.join(LocatorDelimiter,
                        filePath, className, methodName))
                .suiteID(suiteID)
                .build();
    }

    public static TestExecutionObject createTestResult(ITestResult result) {
        String className = result.getTestClass().getName();
        String methodName = result.getName();
        String filePath = fullQualifiedNameToPath(className);
        String methodNameWithParams = methodName;
        if (!StringUtils.isBlank(result.getMethod().getDescription())) {
            String[] subString = result.getMethod().getDescription().split("#TAS#");
            if (subString.length > 1) {
                methodNameWithParams = subString[1];
            }
        }
        String testID = MD5.getMd5(String.join("\n", RepoID,
                className, methodNameWithParams));
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));
        Throwable t = result.getThrowable();
        String reason = t == null ? null : t.getMessage();

        return TestExecutionObject.childBuilder().testID(
                        testID
                ).title(
                        methodNameWithParams
                ).testName(
                        methodNameWithParams
                ).className(
                        className
                ).filepath(
                        filePath
                ).locator(String.join(LocatorDelimiter,
                        filePath, className, methodName))
                .suiteID(suiteID)
                .start_time(Instant.ofEpochMilli(result.getStartMillis()).toString())
                .end_time(Instant.ofEpochMilli(result.getEndMillis()).toString())
                .duration(result.getEndMillis() - result.getStartMillis())
                .failureMessage(reason)
                .status(getStatus(result.getStatus()))
                .build();
    }

    public static TestExecutionObject createBlockListedTestResult(Method testMethod) {
        TestObject test = createTest(testMethod);
        return TestExecutionObject.childBuilder().testID(
                        test.getTestID()
                ).title(
                        test.getTitle()
                ).testName(
                        test.getTestName()
                ).className(
                        test.getClassName()
                ).filepath(
                        test.getFilepath()
                ).locator(test.getLocator())
                .suiteID(test.getSuiteID())
                .duration(0)
                .status(Status.blocklisted)
                .build();
    }

    public static TestSuiteExecutionObject createSuiteResult(IClass testClass) {
        String className = testClass.getName();
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));
        String filePath = fullQualifiedNameToPath(className);
        return TestSuiteExecutionObject.childBuilder().suiteID(suiteID)
                .locator(String.join(LocatorDelimiter, filePath, className))
                .suiteName(className).build();
    }

    public static TestSuiteExecutionObject createBlockListedSuiteResult(String className) {
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));
        String filePath = fullQualifiedNameToPath(className);
        return TestSuiteExecutionObject.childBuilder().suiteID(suiteID)
                .locator(String.join(LocatorDelimiter, filePath, className))
                .suiteName(className).build();
    }


    private static Status getStatus(int status) {
        Status testStatus;
        switch (status) {
            case ITestResult.SUCCESS_PERCENTAGE_FAILURE:
            case ITestResult.SUCCESS:
                testStatus = Status.passed;
                break;
            case ITestResult.FAILURE:
                testStatus = Status.failed;
                break;
            case ITestResult.SKIP:
                testStatus = Status.skipped;
                break;
            default:
                testStatus = Status.blocklisted;
        }
        return testStatus;
    }

    /**
     * Compute the "full name" of a test method, including its parameters, if any.
     */
    public static String getTestMethodNameWithParameters(Method testMethod) {
        Object[] parameters = testMethod.getParameters();
        String name = testMethod.getName();

        if (parameters == null || parameters.length == 0) {
            return name;
        }
        StringBuilder builder = new StringBuilder(name).append(" (");
        builder.append(
                Arrays.stream(parameters)
                        .map(
                                parameter -> {
                                    try {
                                        return String.valueOf(parameter);
                                    } catch (Exception e) {
                                        return "Unstringable object";
                                    }
                                })
                        .collect(Collectors.joining(", ")));
        builder.append(")");
        return builder.toString();
    }


}
