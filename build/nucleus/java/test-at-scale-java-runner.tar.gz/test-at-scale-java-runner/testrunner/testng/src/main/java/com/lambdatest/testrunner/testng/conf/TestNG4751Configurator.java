package com.lambdatest.testrunner.testng.conf;




/**
 * TestNG 4.7 and 5.1 configurator.
 * <br>
 * Allowed options:
 * -groups
 * -excludedgroups
 * -junit (boolean)
 * -threadcount (int)
 * -parallel (boolean)
 * <br>
 *
 */
public class TestNG4751Configurator
    extends AbstractDirectConfigurator
{
    public TestNG4751Configurator()
    {
        setters.put( AbstractDirectConfigurator.PARALLEL_PROP, new Setter( "setParallel", boolean.class ) );
    }
}
