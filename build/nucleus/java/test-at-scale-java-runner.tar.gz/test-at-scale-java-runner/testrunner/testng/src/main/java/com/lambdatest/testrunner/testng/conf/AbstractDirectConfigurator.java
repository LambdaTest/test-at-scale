package com.lambdatest.testrunner.testng.conf;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlSuite;

/**
 * Configurator that relies on reflection to set parameters in TestNG
 *
 */
public abstract class AbstractDirectConfigurator
    implements Configurator
{
    final Map<String, Setter> setters;

    public static final String THREADCOUNT_PROP = "threadcount";

    public static final String PARALLEL_PROP = "parallel";

    AbstractDirectConfigurator()
    {
        Map<String, Setter> options = new HashMap<>();
        options.put( "junit", new Setter( "setJUnit", Boolean.class ) );
        options.put( THREADCOUNT_PROP, new Setter( "setThreadCount", int.class ) );
        options.put( "usedefaultlisteners", new Setter( "setUseDefaultListeners", boolean.class ) );
        this.setters = options;
    }

    @Override
    public void configure( TestNG testng, Map<String, String> options )
        throws RuntimeException
    {
        System.out.println( "\n\n\n\nCONFIGURING TESTNG\n\n\n\n" );
        // kind of ugly, but listeners are configured differently
        final String listeners = options.remove( "listener" );
        // DGF In 4.7, default listeners dump XML files in the surefire-reports directory,
        // confusing the report plugin.  This was fixed in later versions.
        testng.setUseDefaultListeners( false );
        configureInstance( testng, options );
        // TODO: we should have the Profile so that we can decide if this is needed or not
        testng.setListenerClasses( loadListenerClasses( listeners ) );
    }

    @Override
    public void configure( XmlSuite suite, Map<String, String> options )
        throws RuntimeException
    {
        Map<String, String> filtered = filterForSuite( options );
        configureInstance( suite, filtered );
    }

    protected Map<String, String> filterForSuite( Map<String, String> options )
    {
        Map<String, String> result = new HashMap<>();
        addPropIfNotNull( options, result, PARALLEL_PROP );
        addPropIfNotNull( options, result, THREADCOUNT_PROP );
        return result;
    }

    private void addPropIfNotNull( Map<String, String> options, Map<String, String> result, String prop )
    {
        if ( options.containsKey( prop ) )
        {
            result.put( prop, options.get( prop ) );
        }
    }

    private void configureInstance( Object testngInstance, Map<String, String> options )
    {
        for ( Map.Entry<String, String> entry : options.entrySet() )
        {
            String key = entry.getKey();
            String val = entry.getValue();
            Setter setter = setters.get( key );
            if ( setter != null )
            {
                try
                {
                    setter.invoke( testngInstance, val );
                }
                catch ( Exception e )
                {
                    throw new RuntimeException( "Cannot set option " + key + " with value " + val, e );
                }
            }
        }
    }

    static List<Class> loadListenerClasses( String listenerClasses )
        throws RuntimeException
    {
        if ( listenerClasses == null || listenerClasses.trim().isEmpty() )
        {
            return new ArrayList<>();
        }

        List<Class> classes = new ArrayList<>();
        String[] classNames = listenerClasses.split( "\\s*,\\s*(\\r?\\n)?\\s*" );
        for ( String className : classNames )
        {
            Class<?> clazz = loadClass( className );
            classes.add( clazz );
        }

        return classes;
    }

    static Class<?> loadClass( String className )
        throws RuntimeException
    {
        try
        {
            return Class.forName( className );
        }
        catch ( Exception ex )
        {
            throw new RuntimeException( "Cannot find listener class " + className, ex );
        }
    }

    /**
     * Describes a property setter by method name and parameter class
     *
     */
    public static final class Setter
    {
        private final String setterName;

        private final Class<?> paramClass;

        public Setter( String name, Class<?> clazz )
        {
            setterName = name;
            paramClass = clazz;
        }

        public void invoke( Object target, String value )
            throws Exception
        {
            Method setter = target.getClass().getMethod( setterName, paramClass );
            if ( setter != null )
            {
                setter.invoke( target, convertValue( value ) );
            }
        }

        private Object convertValue( String value )
        {
            if ( value == null )
            {
                return null;
            }
            if ( paramClass.isAssignableFrom( value.getClass() ) )
            {
                return value;
            }

            if ( Boolean.class.equals( paramClass ) || boolean.class.equals( paramClass ) )
            {
                return Boolean.valueOf( value );
            }
            if ( Integer.class.equals( paramClass ) || int.class.equals( paramClass ) )
            {
                return Integer.valueOf( value );
            }

            return value;
        }
    }
}
