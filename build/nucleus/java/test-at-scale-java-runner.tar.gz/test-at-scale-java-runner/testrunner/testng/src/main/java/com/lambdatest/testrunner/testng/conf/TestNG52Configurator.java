package com.lambdatest.testrunner.testng.conf;

/**
 * TestNG 5.2 configurator.
 * <br>
 * Allowed options:
 * -groups
 * -excludedgroups
 * -junit (boolean)
 * -threadcount (int)
 * -parallel (String)
 * <br>
 *
 * @author <a href='mailto:the[dot]mindstorm[at]gmail[dot]com'>Alex Popescu</a>
 */
public class TestNG52Configurator
        extends AbstractDirectConfigurator {
    public TestNG52Configurator() {
        setters.put(AbstractDirectConfigurator.PARALLEL_PROP, new Setter("setParallel", String.class));
    }
}
