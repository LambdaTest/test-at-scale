package com.lambdatest.testrunner.testng;

import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentMap;

import static com.lambdatest.testrunner.testng.TestNGHelper.*;

//FIXME: https://github.com/cbeust/testng/issues/2730

public class TestNGDiscoveryListener implements IAnnotationTransformer {

    // TestNG can run a test class's tests in parallel via DataProvider.
    // Use concurrency-safe collection to avoid co-modification errors.
    final ConcurrentMap<String, TestObject> testCases;

    final ConcurrentMap<String, TestSuiteObject> testSuites;

    private final Boolean dryRun = true;

    TestNGDiscoveryListener(ConcurrentMap<String, TestObject> testCases, ConcurrentMap<String, TestSuiteObject> testSuites) {
        this.testSuites = testSuites;
        this.testCases = testCases;
    }

    @Override
    public void transform(
            ITestAnnotation annotation,
            Class testClass,
            Constructor testConstructor,
            Method testMethod) {
        if (testMethod == null || annotation == null) {
            return;
        }
        //  ignoring disabled tests, will not be recorded
        if (!annotation.getEnabled()) {
            return;
        }
        // disable all test cases in case of dry running of tests
        TestObject test = createTest(testMethod);
        testCases.putIfAbsent(test.getTestID(), test);
        TestSuiteObject suite = createSuite(testMethod.getDeclaringClass());
        testSuites.putIfAbsent(suite.getSuiteID(), suite);
        annotation.setEnabled(false);

    }
}
