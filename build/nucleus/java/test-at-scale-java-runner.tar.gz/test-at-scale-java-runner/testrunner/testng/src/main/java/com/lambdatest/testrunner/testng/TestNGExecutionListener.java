package com.lambdatest.testrunner.testng;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import org.testng.*;
import org.testng.annotations.ITestAnnotation;
import org.testng.internal.IResultListener;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.time.Instant;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

import static com.lambdatest.testrunner.testng.TestNGHelper.*;

public class TestNGExecutionListener implements IResultListener, ISuiteListener, IAnnotationTransformer {

    private final ConcurrentMap<String, Boolean> testAnnotated;

    private final Collection<TestExecutionObject> testResults;

    private final ConcurrentMap<String, TestSuiteExecutionObject> testSuiteResultsMap;

    private final Collection<TestSuiteExecutionObject> testSuiteResults;

//    private final ConcurrentMap<String, TestExecutionObject> blockListedTests;

    private final Logger logger;

    public TestNGExecutionListener(
            Logger logger) {
        //    need to use because of FIXME: https://github.com/cbeust/testng/issues/2730
        this.testResults = new ConcurrentLinkedQueue<>();
        ;
        this.testSuiteResults = new ConcurrentLinkedQueue<>();
        this.testSuiteResultsMap = new ConcurrentHashMap<>();
        this.logger = logger;
        this.testAnnotated = new ConcurrentHashMap<>();
//        this.blockListedTests = new ConcurrentHashMap<>();
    }

    @Override
    public void onTestStart(ITestResult result) {
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        recordResult(result);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        recordResult(result);
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        recordResult(result);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        recordResult(result);
    }

    @Override
    public void onStart(ITestContext context) {
    }

    @Override
    public void onFinish(ITestContext context) {
    }

    @Override
    public void onStart(ISuite s) {
        // clear the map
        testAnnotated.clear();
    }

    @Override
    public void onFinish(ISuite s) {
        testSuiteResultsMap.forEach((k, v) -> {
            // find the winner status of the test suite;
            Instant i = Instant.parse(v.getStart_time()).plusMillis(v.getDuration());
            v.setEnd_time(i.toString());
            v.setStatus(v.winnerSuiteStatus());
            testSuiteResults.add(v);
        });
        // clear test suite results map
        testSuiteResultsMap.clear();
        //TODO: add blocklisted tests and update suite as well.
//        blockListedTests.entrySet().forEach((entry) -> {
//            TestExecutionObject test = entry.getValue();
//            testResults.add(test);
//            TestSuiteExecutionObject suite = testSuiteResults.get(test.getSuiteID());
//            if (suite != null) {
//                updateSuite(suite, entry.getValue());
//            } else {
//                TestSuiteExecutionObject suiteResult = createBlockListedSuiteResult(test.getClassName());
//                updateSuite(suiteResult, entry.getValue());
//                testSuiteResults.put(suiteResult.getSuiteID(), suiteResult);
//            }
//        });
//        blockListedTests.clear();
    }

    public void onConfigurationFailure(ITestResult result) {
    }

    public void onConfigurationSkip(ITestResult result) {
    }

    public void onConfigurationSuccess(ITestResult result) {
    }


    @Override
    public void transform(
            ITestAnnotation annotation,
            Class testClass,
            Constructor testConstructor,
            Method testMethod) {

        if (testMethod == null || annotation == null) {
            return;
        }
        //  ignoring disabled tests, will not be recorded
        if (!annotation.getEnabled()) {
            return;
        }
        // TODO: for blocklisting
//        // have to record it now -- since it doesn't run, listener can't do it
//        if (blocklisted){
//            TestExecutionObject disabledTest = createBlockListedTestResult(testMethod);
//            blockListedTests.putIfAbsent(disabledTest.getTestID(), disabledTest);
//        }
//
        if (testMethod.getParameterCount() < 1) {
            return;
        }

        String description = annotation.getDescription() != null ? annotation.getDescription() : "";
        if (!testAnnotated.containsKey(description)) {
            String newDescription = String.join("#TAS#", description, getTestMethodNameWithParameters(testMethod));
            annotation.setDescription(newDescription);
            testAnnotated.put(newDescription, true);
        }
    }

    private void recordResult(ITestResult result) {
        TestExecutionObject test = createTestResult(result);
        testResults.add(test);
        TestSuiteExecutionObject suite = testSuiteResultsMap.get(test.getSuiteID());
        if (suite != null) {
            updateSuite(suite, test);
        } else {
            TestSuiteExecutionObject suiteResult = createSuiteResult(result.getTestClass());
            updateSuite(suiteResult, test);
            testSuiteResultsMap.put(suiteResult.getSuiteID(), suiteResult);
        }
    }

    private static void updateSuite(TestSuiteExecutionObject suite, TestExecutionObject test) {
        suite.setDuration(suite.getDuration() + test.getDuration());
        suite.setTotalExecutedTests(suite.getTotalExecutedTests() + 1);
        // set the start time of the first test as the start  time of test
        if (suite.getStart_time() == null) {
            suite.setStart_time(test.getStart_time());
        }
        switch (test.getStatus()) {
            case passed:
                suite.setTotalTestsPassed(suite.getTotalTestsPassed() + 1);
                break;
            case failed:
                suite.setTotalTestsFailed(suite.getTotalTestsFailed() + 1);
                break;
            case skipped:
                suite.setTotalTestsSkipped(suite.getTotalTestsSkipped() + 1);
        }
    }

    public Collection<TestExecutionObject> getTestResults() {
        return this.testResults;
    }

    public Collection<TestSuiteExecutionObject> getSuiteResults() {
        return this.testSuiteResults;
    }

}

