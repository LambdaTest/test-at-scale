package com.lambdatest.testrunner.testng;


import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.request.RequestUtils;
import com.lambdatest.testrunner.testng.conf.Configurator;
import org.apache.commons.lang3.StringUtils;
import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlMethodSelector;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static com.lambdatest.runner.api.reflection.ReflectionUtils.tryLoadClass;


final class TestNGExecutor {

    private final RequestUtils request;

    /**
     * The default name for a suite launched from the maven surefire plugin
     */
    private static final String DEFAULT_SUREFIRE_SUITE_NAME = "Surefire suite";

    /**
     * The default name for a test launched from the maven surefire plugin
     */
    private static final String DEFAULT_SUREFIRE_TEST_NAME = "Surefire test";

    public static final String TESTNG_EXCLUDEDGROUPS_PROP = "excludegroups";

    public static final String TESTNG_GROUPS_PROP = "groups";

    private static final boolean HAS_TEST_ANNOTATION_ON_CLASSPATH =
            tryLoadClass(TestNGExecutor.class.getClassLoader(), "org.testng.annotations.Test") != null;

    private TestNGExecutor() {
        throw new IllegalStateException("not instantiable constructor");
    }

    //    TODO: add selectors
    @SuppressWarnings("checkstyle:parameternumbercheck")
    static void execute(Iterable<Class<?>> testClasses, String testSourceDirectory,
                        Map<String, String> options, // string,string because TestNGMapConfigurator#configure()
                        ITestNGListener reportManager, File reportsDirectory,
                        String methodFilter
    )
            throws RuntimeException {
        TestNG testng = new TestNG(true);
        Configurator configurator = getConfigurator(options.get("testng.configurator"));
        List<XmlSuite> xmlSuites = xmlSuitesFromClasses(testClasses, configurator, options, methodFilter);
        System.out.println("Configuring TestNG with: " + configurator.getClass().getSimpleName());
        testng.setXmlSuites(xmlSuites);
        configurator.configure(testng, options);
        postConfigure(testng, testSourceDirectory, reportManager, reportsDirectory,
                extractVerboseLevel(options));
        testng.run();
    }


    private static TestMetadata findTestMetadata(Class<?> testClass) {
        TestMetadata result = new TestMetadata();
        if (HAS_TEST_ANNOTATION_ON_CLASSPATH) {
            Test testAnnotation = findAnnotation(testClass, Test.class);
            if (null != testAnnotation) {
                if (!StringUtils.isBlank(testAnnotation.suiteName())) {
                    result.suiteName = testAnnotation.suiteName();
                }

                if (!StringUtils.isBlank(testAnnotation.testName())) {
                    result.testName = testAnnotation.testName();
                }
            }
        }
        return result;
    }

    private static <T extends Annotation> T findAnnotation(Class<?> clazz, Class<T> annotationType) {
        if (clazz == null) {
            return null;
        }

        T result = clazz.getAnnotation(annotationType);
        if (result != null) {
            return result;
        }

        return findAnnotation(clazz.getSuperclass(), annotationType);
    }

    private static class TestMetadata {
        private String testName = DEFAULT_SUREFIRE_TEST_NAME;

        private String suiteName = DEFAULT_SUREFIRE_SUITE_NAME;
    }

    private static class SuiteAndNamedTests {
        private XmlSuite xmlSuite = new XmlSuite();

        private Map<String, XmlTest> testNameToTest = new HashMap<>();
    }

    private static void addSelector(XmlTest xmlTest, XmlMethodSelector selector) {
        if (selector != null) {
            xmlTest.getMethodSelectors().add(selector);
        }
    }

    @SuppressWarnings("checkstyle:magicnumber")
    private static XmlMethodSelector createMethodNameFilteringSelector(String className)
            throws RuntimeException {

        if (StringUtils.isBlank(className)) {
            return null;
        }
        XmlMethodSelector xms = new XmlMethodSelector();
        xms.setName(className);
        // looks to need a high value
        xms.setPriority(10000);
        return xms;
    }

    @SuppressWarnings("checkstyle:magicnumber")
    private static XmlMethodSelector createGroupMatchingSelector(Map<String, String> options)
            throws RuntimeException {
        final String groups = options.get(TESTNG_GROUPS_PROP);
        final String excludedGroups = options.get(TESTNG_EXCLUDEDGROUPS_PROP);

        if (groups == null && excludedGroups == null) {
            return null;
        }

        // the class is available in the testClassPath
        final String clazzName = "org.apache.maven.surefire.testng.utils.GroupMatcherMethodSelector";
        try {
            Class<?> clazz = Class.forName(clazzName);

            // HORRIBLE hack, but TNG doesn't allow us to setup a method selector instance directly.
            Method method = clazz.getMethod("setGroups", String.class, String.class);
            method.invoke(null, groups, excludedGroups);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        XmlMethodSelector xms = new XmlMethodSelector();

        xms.setName(clazzName);
        // looks to need a high value
        xms.setPriority(9999);

        return xms;
    }

    static void execute(List<String> suiteFiles,
                        String testSourceDirectory,
                        Map<String, String> options,
                        ITestNGListener reportManager,
                        File reportsDirectory)
            throws RuntimeException {
        TestNG testng = new TestNG(true);

        Configurator configurator = getConfigurator(options.get("testng.configurator"));
        configurator.configure(testng, options);
        postConfigure(testng, testSourceDirectory, reportManager, reportsDirectory,
                extractVerboseLevel(options));
        testng.setTestSuites(suiteFiles);
        testng.run();
    }


    static void discover(List<String> suiteFiles,
                         String testSourceDirectory,
                         Map<String, String> options,
                         Collection<TestObject> testList,
                         Collection<TestSuiteObject> testSuiteList)
            throws RuntimeException {
        // don't use default listeners if in discovery mode
        TestNG testng = new TestNG(false);
        Configurator configurator = getConfigurator(options.get("testng.configurator"));
        configurator.configure(testng, options);
        postConfigure(testng, testSourceDirectory, null, null,
                extractVerboseLevel(options));
        ConcurrentMap<String, TestObject> uniqueTestCases = new ConcurrentHashMap<>();
        ConcurrentMap<String, TestSuiteObject> uniqueTestSuites = new ConcurrentHashMap<>();
        testng.addListener(new TestNGDiscoveryListener(uniqueTestCases, uniqueTestSuites));
        testng.setTestSuites(suiteFiles);
        testng.run();
        uniqueTestCases.entrySet().forEach(entry -> {
            testList.add(entry.getValue());
        });
        uniqueTestSuites.entrySet().forEach(entry -> {
            testSuiteList.add(entry.getValue());
        });
    }

    //    can also use only reflection for test class discovery
    static void discover(Iterable<Class<?>> testClasses,
                         String testSourceDirectory,
                         Map<String, String> options,
                         String methodFilter,
                         Collection<TestObject> testList,
                         Collection<TestSuiteObject> testSuiteList
    ) throws RuntimeException {
        TestNG testng = new TestNG(false);
        ConcurrentMap<String, TestObject> uniqueTestCases = new ConcurrentHashMap<>();
        ConcurrentMap<String, TestSuiteObject> uniqueTestSuites = new ConcurrentHashMap<>();
        Configurator configurator = getConfigurator(options.get("testng.configurator"));
        List<XmlSuite> xmlSuites = xmlSuitesFromClasses(testClasses, configurator, options, methodFilter);
        configurator.configure(testng, options);
        postConfigure(testng, testSourceDirectory, null, null,
                extractVerboseLevel(options));
        testng.addListener(new TestNGDiscoveryListener(uniqueTestCases, uniqueTestSuites));
        testng.setXmlSuites(xmlSuites);
        testng.run();
        uniqueTestCases.entrySet().forEach(entry -> {
            testList.add(entry.getValue());
        });
        uniqueTestSuites.entrySet().forEach(entry -> {
            testSuiteList.add(entry.getValue());
        });
    }

    private static Configurator getConfigurator(String className) {
        String configClass = StringUtils.substringAfterLast(className, ".");
        className = "com.lambdatest.testrunner.testng.conf." + configClass;
        try {
            return (Configurator) Class.forName(className).newInstance();
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static void postConfigure(TestNG testNG, String sourcePath,
                                      final ITestNGListener resultReporter,
                                      File reportsDirectory,
                                      int verboseLevel) {
        // 0 (default): turn off all TestNG output
        testNG.setVerbose(verboseLevel);
        // disabling parallel test execution and thread count by default for now
        testNG.setThreadCount(1);
        testNG.setParallel(null);

        // FIXME: use classifier to decide if we need to pass along the source dir (only for JDK14)
        if (sourcePath != null) {
            testNG.setSourcePath(sourcePath);
        }
        if (resultReporter != null) {
            testNG.addListener(resultReporter);
        }
        if (reportsDirectory != null) {
            testNG.setOutputDirectory(reportsDirectory.getAbsolutePath());
        }
    }


    private static int extractVerboseLevel(Map<String, String> options)
            throws RuntimeException {
        try {
            String verbose = options.get("surefire.testng.verbose");
            return verbose == null ? 0 : Integer.parseInt(verbose);
        } catch (NumberFormatException e) {
            throw new RuntimeException("Provider property 'surefire.testng.verbose' should refer to "
                    + "number -1 (debug mode), 0, 1 .. 10 (most detailed).", e);
        }
    }

    private static List<XmlSuite> xmlSuitesFromClasses(Iterable<Class<?>> testClasses, Configurator
            configurator, Map<String, String> options, String methodFilter) {
        Map<String, SuiteAndNamedTests> suitesNames = new HashMap<>();
        List<XmlSuite> xmlSuites = new ArrayList<>();

        XmlMethodSelector groupMatchingSelector = createGroupMatchingSelector(options);
        XmlMethodSelector methodNameFilteringSelector = createMethodNameFilteringSelector(methodFilter);

        for (Class<?> testClass : testClasses) {
            TestMetadata metadata = findTestMetadata(testClass);
            SuiteAndNamedTests suiteAndNamedTests = suitesNames.get(metadata.suiteName);
            if (suiteAndNamedTests == null) {
                suiteAndNamedTests = new SuiteAndNamedTests();
                suiteAndNamedTests.xmlSuite.setName(metadata.suiteName);
                configurator.configure(suiteAndNamedTests.xmlSuite, options);
                xmlSuites.add(suiteAndNamedTests.xmlSuite);

                suitesNames.put(metadata.suiteName, suiteAndNamedTests);
            }

            XmlTest xmlTest = suiteAndNamedTests.testNameToTest.get(metadata.testName);
            if (xmlTest == null) {
                xmlTest = new XmlTest(suiteAndNamedTests.xmlSuite);
                xmlTest.setName(metadata.testName);
                addSelector(xmlTest, groupMatchingSelector);
                addSelector(xmlTest, methodNameFilteringSelector);
                xmlTest.setXmlClasses(new ArrayList<>());
                suiteAndNamedTests.testNameToTest.put(metadata.testName, xmlTest);
            }
            xmlTest.getXmlClasses().add(new XmlClass(testClass.getName()));
        }

        return xmlSuites;
    }


}
