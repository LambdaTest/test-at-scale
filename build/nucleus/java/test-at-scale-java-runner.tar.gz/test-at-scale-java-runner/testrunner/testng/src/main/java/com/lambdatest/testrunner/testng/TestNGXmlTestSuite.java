package com.lambdatest.testrunner.testng;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.request.RequestUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;


public final class TestNGXmlTestSuite {
    private final List<File> suiteFiles;

    private List<String> suiteFilePaths;
    //
    private final String testSourceDirectory;

    private final Map<String, String> options;
    //
    private final File reportsDirectory;

    private final RequestUtils request;
//

    /**
     * Creates a testng testset to be configured by the specified
     * xml file(s). The XML files are suite definitions files according to TestNG DTD.
     */
    public TestNGXmlTestSuite(List<File> suiteFiles, String testSourceDirectory, Map<String, String> confOptions,
                              File reportsDirectory, Logger logger) {
        this.suiteFiles = suiteFiles;
        this.options = confOptions;
        this.testSourceDirectory = testSourceDirectory;
        this.reportsDirectory = reportsDirectory;
        this.request = new RequestUtils(logger);

    }

    public void discover() throws RuntimeException {
        if (suiteFilePaths == null) {
            throw new IllegalStateException("You must call locateTestSets before calling execute");
        }
        Collection<TestObject> tests = new ArrayList<>();
        Collection<TestSuiteObject> testSuites = new ArrayList<>();
        TestNGExecutor.discover(suiteFilePaths, testSourceDirectory, options, tests, testSuites);
        this.request.sendDiscoveryResult(tests, testSuites);
    }


    public void execute(TestNGExecutionListener testNGReporter)
            throws RuntimeException {
        if (suiteFilePaths == null) {
            throw new IllegalStateException("You must call locateTestSets before calling execute");
        }
        TestNGExecutor.execute(suiteFilePaths, testSourceDirectory, options, testNGReporter, reportsDirectory);
        this.request.sendExecutionResult(testNGReporter.getTestResults(), testNGReporter.getSuiteResults());
    }

    public Iterable locateTestSets()
            throws RuntimeException {
        if (suiteFilePaths != null) {
            throw new IllegalStateException("You can't call locateTestSets twice");
        }

        if (suiteFiles.isEmpty()) {
            throw new IllegalStateException("No suite files were specified");
        }

        suiteFilePaths = new ArrayList<>(suiteFiles.size());
        ArrayList<File> testSets = new ArrayList<>(suiteFiles.size());

        for (File suiteFile : suiteFiles) {
            if (!suiteFile.isFile()) {
                throw new RuntimeException("Suite file " + suiteFile + " is not a valid file");
            }
            testSets.add(suiteFile);
            suiteFilePaths.add(suiteFile.getAbsolutePath());
        }
        return testSets;
    }

}

