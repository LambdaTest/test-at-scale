package  com.lambdatest.testrunner.testng.conf;


import java.util.Map;
import java.util.Map.Entry;

/**
 * TestNG 6.0 configurator. Changed objectFactory type to String.
 * Configuring -objectfactory and -testrunfactory.
 *
 * @author <a href='mailto:marvin[at]marvinformatics[dot]com'>Marvin Froeder</a>
 * @since 2.13
 */
public class TestNG60Configurator
    extends TestNG5143Configurator
{

    @Override
    Map<String, Object> getConvertedOptions( Map<String, String> options )
        throws RuntimeException
    {
        Map<String, Object> convertedOptions = super.getConvertedOptions( options );
        for ( Entry<String, Object> entry : convertedOptions.entrySet() )
        {
            String key = entry.getKey();
            if ( "-objectfactory".equals( key ) || "-testrunfactory".equals( key ) )
            {
                Class value = (Class) entry.getValue();
                convertedOptions.put( key, value.getName() );
                break;
            }
        }
        return convertedOptions;
    }
}
