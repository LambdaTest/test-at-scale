package com.lambdatest.testrunner.testng.conf;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlSuite;

/**
 * TestNG configurator for 5.3+ versions. TestNG exposes a {@link org.testng.TestNG#configure(java.util.Map)} method.
 * All supported TestNG options are passed in String format, except
 * {@link org.testng.TestNGCommandLineArgs#LISTENER_COMMAND_OPT} which is {@link java.util.List List&gt;Class&lt;},
 * {@link org.testng.TestNGCommandLineArgs#JUNIT_DEF_OPT} which is a {@link Boolean},
 * {@link org.testng.TestNGCommandLineArgs#SKIP_FAILED_INVOCATION_COUNT_OPT} which is a {@link Boolean},
 * {@link org.testng.TestNGCommandLineArgs#OBJECT_FACTORY_COMMAND_OPT} which is a {@link Class},
 * {@link org.testng.TestNGCommandLineArgs#REPORTERS_LIST} which is a {@link java.util.List List&gt;ReporterConfig&lt;}.
 * <br>
 * Test classes and/or suite files are not passed along as options parameters, but configured separately.
 *
 * @author <a href='mailto:the[dot]mindstorm[at]gmail[dot]com'>Alex Popescu</a>
 */
public class TestNGMapConfigurator
        implements Configurator {
    @Override
    public void configure(TestNG testng, Map<String, String> options)
            throws RuntimeException {
        Map convertedOptions = getConvertedOptions(options);
        testng.configure(convertedOptions);
    }

    @Override
    public void configure(XmlSuite suite, Map<String, String> options)
            throws RuntimeException {
        configureThreadCount(suite, options);
        configureParallel(suite, options);
    }

    protected void configureThreadCount(XmlSuite suite, Map<String, String> options)
            throws RuntimeException {
        String threadCount = options.get(AbstractDirectConfigurator.THREADCOUNT_PROP);
        if (threadCount != null) {
            try {
                suite.setThreadCount(Integer.parseInt(threadCount));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Non-integer TestNG [threadcount] setting: " + threadCount, e);
            }
        }
    }

    protected void configureParallel(XmlSuite suite, Map<String, String> options)
            throws RuntimeException {
        String parallel = options.get(AbstractDirectConfigurator.PARALLEL_PROP);
        if (parallel != null) {
            suite.setParallel(parallel);
        }
    }

    Map<String, Object> getConvertedOptions(Map<String, String> options)
            throws RuntimeException {
        Map<String, Object> convertedOptions = new HashMap<>();
        convertedOptions.put("-mixed", false);
        for (Map.Entry<String, String> entry : options.entrySet()) {
            String key = entry.getKey();
            Object val = entry.getValue();
            switch (key) {
                case "listener":
                    val = convertListeners(entry.getValue());
                    break;
                case "objectfactory":
                case "testrunfactory":
                    val = AbstractDirectConfigurator.loadClass(entry.getValue());
                    break;
                case "reporter":
                    // for TestNG 5.6 or higher
                    // TODO support multiple reporters?
                    val = convertReporterConfig(val);
                    key = "reporterslist";
                    break;
                case "junit":
                case "skipfailedinvocationcounts":
                case "mixed":
                case "group-by-instances":
                    val = convert(val, Boolean.class);
                    break;
                case "configfailurepolicy":
                case AbstractDirectConfigurator.THREADCOUNT_PROP:
                    // minimum thread count should be one
                    if (val.equals("0")) {
                        val = "1";
                    }
                    val = convert(val, String.class);
                    break;
                // for TestNG 6.9.7 or higher
                case "suitethreadpoolsize":
                    // for TestNG 5.10 or higher
                case "dataproviderthreadcount":
                    val = convert(val, Integer.class);
                    break;
                default:
                    continue;
            }

            if (key.startsWith("-")) {
                convertedOptions.put(key, val);
            } else {
                convertedOptions.put("-" + key, val);
            }
        }
        return convertedOptions;
    }

    // ReporterConfig only became available in later versions of TestNG
    protected Object convertReporterConfig(Object val) {
        try {
            Class<?> reporterConfig = Class.forName("org.testng.ReporterConfig");
            Method deserialize = reporterConfig.getMethod("deserialize", String.class);
            Object rc = deserialize.invoke(null, val);
            ArrayList<Object> reportersList = new ArrayList<>();
            reportersList.add(rc);
            return reportersList;
        } catch (Exception e) {
            return val;
        }
    }

    protected Object convertListeners(String listenerClasses) throws RuntimeException {
        return AbstractDirectConfigurator.loadListenerClasses(listenerClasses);
    }

    protected Object convert(Object val, Class<?> type) {
        if (val == null) {
            return null;
        } else if (type.isAssignableFrom(val.getClass())) {
            return val;
        } else if ((type == Boolean.class || type == boolean.class) && val.getClass() == String.class) {
            return Boolean.valueOf((String) val);
        } else if ((type == Integer.class || type == int.class) && val.getClass() == String.class) {
            return Integer.valueOf((String) val);
        } else if (type == String.class) {
            return val.toString();
        } else {
            return val;
        }
    }
}
