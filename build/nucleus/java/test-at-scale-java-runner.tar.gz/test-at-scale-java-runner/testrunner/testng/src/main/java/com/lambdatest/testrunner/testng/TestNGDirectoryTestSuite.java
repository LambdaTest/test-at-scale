package com.lambdatest.testrunner.testng;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.request.RequestUtils;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.*;

import static org.apache.commons.lang3.StringUtils.isBlank;

public class TestNGDirectoryTestSuite {
    private final Map<String, String> options;

    private final Map<String, String> junitOptions;

    private final String testSourceDirectory;

    private final File reportsDirectory;

    private final String methodFilter;

    private final Class<?> junitTestClass;

    private final Class<? extends Annotation> junitRunWithAnnotation;

    private final Class<? extends Annotation> junitTestAnnotation;

    private final Iterable<Class<?>> testClasses;

    private final RequestUtils request;


    public TestNGDirectoryTestSuite(Iterable<Class<?>> testClasses,
                                    String testSourceDirectory,
                                    Map<String, String> confOptions,
                                    File reportsDirectory,
                                    String methodFilterClassName,
                                    Logger logger) {
        this.options = confOptions;
        this.testSourceDirectory = testSourceDirectory;
        this.reportsDirectory = reportsDirectory;
        this.methodFilter = methodFilterClassName;
        this.junitTestClass = findJUnitTestClass();
        this.junitRunWithAnnotation = findJUnitRunWithAnnotation();
        this.junitTestAnnotation = findJUnitTestAnnotation();
        this.junitOptions = createJUnitOptions();
        this.testClasses = testClasses;
        this.request = new RequestUtils(logger);
    }


    //    TODO: junit handling
    public void discover() throws RuntimeException {
        Collection<TestObject> tests = new ArrayList<>();
        Collection<TestSuiteObject> testSuites = new ArrayList<>();
        TestNGExecutor.discover(testClasses, testSourceDirectory, options, methodFilter, tests, testSuites);
        this.request.sendDiscoveryResult(tests, testSuites);
    }

    public void execute(Iterable<Class<?>> testClasses, TestNGExecutionListener testNGReporter) throws RuntimeException {
        TestNGExecutor.execute(testClasses, testSourceDirectory, options, testNGReporter, reportsDirectory, methodFilter);
        this.request.sendExecutionResult(testNGReporter.getTestResults(), testNGReporter.getSuiteResults());

    }

    private static Class<?> findJUnitTestClass() {
        return lookupClass("junit.framework.Test");
    }

    private static Class<Annotation> findJUnitRunWithAnnotation() {
        return lookupAnnotation("org.junit.runner.RunWith");
    }

    private static Class<Annotation> findJUnitTestAnnotation() {
        return lookupAnnotation("org.junit.Test");
    }

    @SuppressWarnings("unchecked")
    private static Class<Annotation> lookupAnnotation(String className) {
        try {
            return (Class<Annotation>) Class.forName(className);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private static Class<?> lookupClass(String className) {
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private boolean isJUnitTest(Class<?> c) {
        return isJunit3Test(c) || isJunit4Test(c);
    }

    private boolean isJunit4Test(Class<?> c) {
        return hasJunit4RunWithAnnotation(c) || hasJunit4TestAnnotation(c);
    }

    private boolean hasJunit4RunWithAnnotation(Class<?> c) {
        return junitRunWithAnnotation != null && c.getAnnotation(junitRunWithAnnotation) != null;
    }

    private boolean hasJunit4TestAnnotation(Class<?> c) {
        if (junitTestAnnotation != null) {
            for (Method m : c.getMethods()) {
                if (m.getAnnotation(junitTestAnnotation) != null) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isJunit3Test(Class<?> c) {
        return junitTestClass != null && junitTestClass.isAssignableFrom(c);
    }

    private Map<String, String> createJUnitOptions() {
        Map<String, String> junitOptions = new HashMap<>(options);
        String onlyJUnit = options.get("junit");
        if (isBlank(onlyJUnit)) {
            onlyJUnit = "true";
        }
        junitOptions.put("junit", onlyJUnit);
        return junitOptions;
    }


}
