package  com.lambdatest.testrunner.testng.conf;


import com.lambdatest.testrunner.testng.conf.TestNG510Configurator;

/**
 * TestNG 5.13 configurator. Changed: "reporterslist" need String instead of List&lt;ReporterConfig&gt;.
 */
public class TestNG513Configurator
    extends TestNG510Configurator
{

    @Override
    protected Object convertReporterConfig( Object val )
    {
        return val;
    }

    @Override
    protected Object convertListeners( String listenerClasses ) throws RuntimeException
    {
        return convertListenersString( listenerClasses );
    }

    static String convertListenersString( String listenerClasses )
    {
        if ( listenerClasses == null || listenerClasses.trim().isEmpty() )
        {
            return listenerClasses;
        }

        StringBuilder sb = new StringBuilder();
        String[] classNames = listenerClasses.split( "\\s*,\\s*(\\r?\\n)?\\s*" );
        for ( int i = 0; i < classNames.length; i++ )
        {
            String className = classNames[i];
            sb.append( className );
            if ( i < classNames.length - 1 )
            {
                sb.append( ',' );
            }
        }

        return sb.toString();
    }
}
