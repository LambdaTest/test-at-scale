package com.lambdatest.testrunner.testng.conf;

import org.testng.xml.XmlSuite;

import java.util.Map;

/**
 * TestNG 5.10 configurator. Added support of dataproviderthreadcount.
 */

@SuppressWarnings("unused")
public class TestNG510Configurator
        extends TestNGMapConfigurator {

    @Override
    public void configure(XmlSuite suite, Map<String, String> options)
            throws RuntimeException {
        super.configure(suite, options);

        String dataProviderThreadCount = options.get("dataproviderthreadcount");
        if (dataProviderThreadCount != null) {
            suite.setDataProviderThreadCount(Integer.parseInt(dataProviderThreadCount));
        }
    }
}
