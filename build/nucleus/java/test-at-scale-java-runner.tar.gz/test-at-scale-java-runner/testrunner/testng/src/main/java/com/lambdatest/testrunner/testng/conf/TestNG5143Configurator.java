package com.lambdatest.testrunner.testng.conf;


import java.util.Map;

/**
 * TestNG 5.14.3 configurator. Changed: "reporterslist" replaced by "reporter",
 * and "listener" can use String instead of List&lt;Class&gt;.
 */
public class TestNG5143Configurator
        extends TestNG5141Configurator {

    @Override
    Map<String, Object> getConvertedOptions(Map<String, String> options)
            throws RuntimeException {
        Map<String, Object> convertedOptions = super.getConvertedOptions(options);
        for (Map.Entry<String, Object> entry : convertedOptions.entrySet()) {
            String key = entry.getKey();
            if ("-reporterslist".equals(key)) {
                convertedOptions.remove("-reporterslist");
                Object value = entry.getValue();
                convertedOptions.put("-reporter", value);
                break;
            }
        }
        return convertedOptions;
    }


    @Override
    protected Object convertListeners(String listenerClasses) throws RuntimeException {
        return convertListenersString(listenerClasses);
    }
}
