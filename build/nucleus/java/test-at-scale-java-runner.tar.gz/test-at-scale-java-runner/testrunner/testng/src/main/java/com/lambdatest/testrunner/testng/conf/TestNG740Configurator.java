package  com.lambdatest.testrunner.testng.conf;
import org.testng.xml.XmlSuite;
import java.util.Map;

import static com.lambdatest.runner.api.reflection.ReflectionUtils.invokeSetter;
import static com.lambdatest.runner.api.reflection.ReflectionUtils.loadClass;


/**
 * TestNG 7.4.0 configurator. Changed setParallel type to enum value.
 * Uses reflection since ParallelMode enum doesn't exist in supported
 * TestNG 5.x versions.
 *
 */
public class TestNG740Configurator
    extends TestNG60Configurator
{
    /**
     * Convert and apply the value of the [parallel] setting.
     * <p>
     * <b>NOTE</b>: Since TestNG 7.4, the value of the {@code parallel} setting of the {@link XmlSuite} class has been
     * specified via a <b>ParallelMode</b> enumeration. This method converts the [parallel] setting specified in the
     * Surefire plugin configuration to its corresponding constant and applies this to the specified suite object.
     * 
     * @param suite TestNG {@link XmlSuite} object
     * @param options Surefire plugin configuration options
     * @throws RuntimeException if unable to convert specified [parallel] setting
     */
    @Override
    protected void configureParallel( XmlSuite suite, Map<String, String> options )
        throws RuntimeException
    {
        String parallel = options.get( AbstractDirectConfigurator.PARALLEL_PROP );
        if ( parallel != null )
        {
            Class enumClass = loadClass( XmlSuite.class.getClassLoader(), "org.testng.xml.XmlSuite$ParallelMode" );
            try
            {
                Enum<?> parallelEnum = Enum.valueOf( enumClass, parallel.toUpperCase() );
                invokeSetter( suite, "setParallel", enumClass, parallelEnum );
            }
            catch ( IllegalArgumentException e )
            {
                throw new RuntimeException( "Unsupported TestNG [parallel] setting: " + parallel, e );
            }
        }
    }
}
