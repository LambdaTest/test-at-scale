package com.lambdatest.testrunner.junit5;

import org.junit.platform.engine.Filter;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

public class Junit5Scanner {

    private final Launcher launcher;

    private final Filter<?>[] includeAndExcludeFilters;

    public Junit5Scanner(Launcher launcher, Filter<?>[] includeAndExcludeFilters) {
        this.launcher = launcher;
        this.includeAndExcludeFilters = includeAndExcludeFilters;
    }

    public boolean accept(Class testClass) {
        LauncherDiscoveryRequest discoveryRequest = request()
                .selectors(selectClass(testClass.getName()))
                .build();

        TestPlan testPlan = launcher.discover(discoveryRequest);
        return testPlan.containsTests();
    }
}
