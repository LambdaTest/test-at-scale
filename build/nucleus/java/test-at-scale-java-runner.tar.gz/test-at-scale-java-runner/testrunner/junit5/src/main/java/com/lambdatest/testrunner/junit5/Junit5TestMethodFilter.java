package com.lambdatest.testrunner.junit5;

import org.junit.platform.engine.FilterResult;
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.PostDiscoveryFilter;

import java.util.function.Function;


public class Junit5TestMethodFilter
        implements PostDiscoveryFilter {

    private final Function<MethodSource, Boolean> isRunnable;

    public Junit5TestMethodFilter( Function<MethodSource, Boolean> isRunnable) {
        this.isRunnable = isRunnable;
    }

    @Override
    public FilterResult apply(TestDescriptor descriptor ) {
        boolean shouldRun = descriptor.getSource()
                .filter(MethodSource.class::isInstance)
                .map(MethodSource.class::cast)
                .map(this.isRunnable)
                .orElse(true);

        return FilterResult.includedIf(shouldRun);
    }
}
