package com.lambdatest.testrunner.junit5;

import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.util.MD5;
import org.junit.platform.engine.support.descriptor.ClassSource;
import org.junit.platform.engine.support.descriptor.MethodSource;

import java.nio.file.Path;
import java.nio.file.Paths;

import static com.lambdatest.runner.api.util.Utils.*;

public class Junit5Helper {
    private static final Path currentDirectory = Paths.get(System.getProperty("user.dir"));

    public static TestSuiteObject createSuite(ClassSource source) {
        String className = source.getClassName();
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));
        String filePath = fullQualifiedNameToPath(className);
        String suiteModifiedClassName = className + String.format(" (%s)",filePath);
        return TestSuiteObject.builder().suiteID(suiteID)
                .locator(String.join(LocatorDelimiter, filePath, className))
                .suiteName(suiteModifiedClassName).build();
    }

    public static TestObject createTest(MethodSource source) {
        String className = source.getClassName();
        String methodName = source.getMethodName();
        String filePath = fullQualifiedNameToPath(className);
        String testID = MD5.getMd5(String.join("\n", RepoID,
                className, methodName, source.getMethodParameterTypes()));
        String suiteID = MD5.getMd5(String.join("\n", RepoID,
                className));

        return TestObject.builder().testID(
                        testID
                ).title(
                        source.getMethodName()
                ).testName(
                        methodName
                ).className(
                        className
                ).filepath(
                        filePath
                ).locator(String.join(LocatorDelimiter,
                        filePath, className, methodName))
                .suiteID(suiteID)
                .build();
    }

    public static TestExecutionObject createTestResult(MethodSource source) {
        TestObject testObject = createTest(source);
        return TestExecutionObject.childBuilder().testID(
                        testObject.getTestID()
                ).testName(testObject.getTestName()).className(
                        testObject.getClassName()
                ).locator(testObject.getLocator()).suiteID(testObject.getSuiteID())
                .build();
    }

    public static TestSuiteExecutionObject createSuiteResult(ClassSource source) {
        TestSuiteObject suite = createSuite(source);
        return TestSuiteExecutionObject.childBuilder().suiteID(suite.getSuiteID())
                .suiteName(suite.getSuiteName())
                .locator(suite.getLocator()).build();
    }

}
