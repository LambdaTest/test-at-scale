package com.lambdatest.testrunner.junit5;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.Status;
import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import org.junit.platform.engine.TestSource;
import org.junit.platform.engine.support.descriptor.ClassSource;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestIdentifier;
import org.junit.platform.launcher.TestPlan;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static com.lambdatest.testrunner.junit5.Junit5Helper.createSuiteResult;
import static com.lambdatest.testrunner.junit5.Junit5Helper.createTestResult;

public class Junit5Listener implements TestExecutionListener {
    private final Logger logger;

    private TestExecutionObject currentTest;

    private TestSuiteExecutionObject currentSuite;

    private final Collection<TestExecutionObject> testCases;

    private final Collection<TestSuiteExecutionObject> testSuites;

    private final ConcurrentMap<TestIdentifier, Long> testStartTime = new ConcurrentHashMap<>();

    public Junit5Listener(Logger logger) {
        this.logger = logger;
        this.testCases = new ArrayList<>();;
        this.testSuites = new ArrayList<>();
    }

    @Override
    public void testPlanExecutionFinished(TestPlan testPlan) {
        testStartTime.clear();
    }

    protected final void startTest(TestIdentifier testIdentifier) {
        logger.info("Starting test: " + testIdentifier.getDisplayName());
        Long startTime = System.currentTimeMillis();
        testStartTime.put(testIdentifier, startTime);
        TestSource testSource = testIdentifier.getSource().orElse(null);
        currentTest = createTestResult((MethodSource) testSource);
        currentTest.setStart_time(Instant.ofEpochMilli(startTime).toString());
    }


    protected final void endTest(long elapsed, long endTime, Status status, String failureMessage) {
        currentTest.setDuration(elapsed);
        currentTest.setEnd_time(Instant.ofEpochMilli(endTime).toString());
        currentTest.setStatus(status);
        currentTest.setFailureMessage(failureMessage);
        testCases.add(currentTest);
    }

    protected final void endSuite(long elapsed, long endTime, Status status) {
        currentSuite.setDuration(elapsed);
        currentSuite.setEnd_time(Instant.ofEpochMilli(endTime).toString());
        currentSuite.setStatus(status);
        testSuites.add(currentSuite);
    }


    protected final void startSuite(TestIdentifier testIdentifier) {
        Long startTime = System.currentTimeMillis();
        testStartTime.put(testIdentifier, startTime);
        TestSource testSource = testIdentifier.getSource().orElse(null);
        currentSuite = createSuiteResult((ClassSource) testSource);
        currentSuite.setStart_time(Instant.ofEpochMilli(startTime).toString());
        logger.info("Starting suite: " + testIdentifier.getDisplayName());
    }

    protected final long computeElapsedTime(TestIdentifier testIdentifier, Long endTime) {
        Long startTime = testStartTime.remove(testIdentifier);
        return startTime == null ? null : (int) (endTime - startTime);
    }

    public Collection<TestExecutionObject> getTestResults() {
        return this.testCases;
    }

    public Collection<TestSuiteExecutionObject> getSuiteResults() {
        return this.testSuites;
    }


}
