package com.lambdatest.testrunner.junit5;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestObject;
import com.lambdatest.runner.api.models.TestSuiteObject;
import com.lambdatest.runner.api.request.RequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.platform.engine.Filter;
import org.junit.platform.engine.TestSource;
import org.junit.platform.engine.support.descriptor.ClassSource;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;

import java.io.IOException;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.lambdatest.testrunner.junit5.Junit5Helper.createSuite;
import static com.lambdatest.testrunner.junit5.Junit5Helper.createTest;
import static java.util.Collections.emptyMap;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

public final class Junit5Executor {

    private final Filter<?>[] filters;

    private static final String CONFIGURATION_PARAMETERS = "configurationParameters";

    private static final String PARALLEL_PROP = "junit.jupiter.execution.parallel.enabled";

    private final Logger logger;

    private final RequestUtils request;

    private final Map<String, String> providerProperties;

    public Junit5Executor(Logger logger,
                          Filter<?>[] filters,
                          Map<String, String> providerProperties) {
        this.logger = logger;
        this.filters = filters;
        this.providerProperties = providerProperties;
        this.request = new RequestUtils(logger);
    }

    public void discover(Launcher launcher,
                         Iterable<Class<?>> testClasses) {
        Collection<TestObject> tests = new ArrayList<>();
        Collection<TestSuiteObject> suites = new ArrayList<>();
        LauncherDiscoveryRequest discoveryRequest = buildLauncherDiscoveryRequest(testClasses);
        TestPlan testPlan = launcher.discover(discoveryRequest);
        for (TestIdentifier root : testPlan.getRoots()) {
            findTests(root, testPlan, tests, suites);
        }
        request.sendDiscoveryResult(tests, suites);
    }

    public void execute(Launcher launcher,
                        Iterable<Class<?>> testClasses,
                        Junit5Listener listener) {
        LauncherDiscoveryRequest discoveryRequest = buildLauncherDiscoveryRequest(testClasses);
        launcher.execute(discoveryRequest, listener);
        request.sendExecutionResult(listener.getTestResults(), listener.getSuiteResults());
    }


    // TODO: In dynamic test currently will give as single test
    // but there will be multiple executions (https://www.baeldung.com/junit5-dynamic-tests)
    //     dynamicTestRegistered(testIdentifier: TestIdentifier) {
    //        testTree.addDynamicDescription(testIdentifier, testIdentifier.parentId.get())
    //    }
    // TODO: consolidate results for @RepeatedTest & @ParameterizedTest
    // TODO: parameter resolver use params to create testID + overloading
    //Note: @Disabled Test not being reported

    private void findTests(TestIdentifier rootNode, TestPlan testPlan,
                           Collection<TestObject> testCases, Collection<TestSuiteObject> testSuites) {
        final Deque<TestIdentifier> nodeStack = new ArrayDeque<>();
        final Deque<Integer> indexStack = new ArrayDeque();
        final Map<String, Integer> suiteTestCount = new HashMap<>();

        TestIdentifier currentNode = rootNode;

        int currentIndex = 0;
        while (currentNode != null) {
            if (!testPlan.getChildren(currentNode).isEmpty()) {
                nodeStack.push(currentNode);
                indexStack.push(currentIndex);
                currentIndex = 0;
                currentNode = (TestIdentifier) testPlan.getChildren(currentNode).toArray()[0];
                continue;
            }
            do {
                TestSource testSource = currentNode.getSource().orElse(null);
                if (testSource instanceof ClassSource) {
                    testSuites.add(createSuite((ClassSource) testSource));
                } else if (testSource instanceof MethodSource) {
                    TestObject test = createTest((MethodSource) testSource);
                    testCases.add(test);
                    suiteTestCount.merge(test.getSuiteID(), 1, Integer::sum);
                }

                // No parent, so no siblings
                if (nodeStack.isEmpty()) {
                    currentNode = null;
                    currentIndex = 0;
                    break;
                }

                // Move to next sibling if possible
                if (testPlan.getChildren(nodeStack.peek()).size() > ++currentIndex) {
                    currentNode = (TestIdentifier) testPlan.getChildren(nodeStack.peek()).toArray()[currentIndex];
                    break;
                }

                // No next, sibling, so move up
                currentNode = nodeStack.pop();
                currentIndex = indexStack.pop();
            } while (currentNode != null);
        }
        for (TestSuiteObject testSuite : testSuites) {
            Integer suiteCount = suiteTestCount.get(testSuite.getSuiteID());
            if (suiteCount != null) {
                testSuite.setTotalTests(suiteCount);
            }
        }
    }

    public LauncherDiscoveryRequest buildLauncherDiscoveryRequest(Iterable<Class<?>> testClasses) {
        LauncherDiscoveryRequestBuilder builder = request().filters(filters).configurationParameters(newConfigurationParameters(providerProperties));
        for (Class<?> testClass : testClasses) {
            builder.selectors(selectClass(testClass));
        }
        return builder.build();
    }

    private Optional<Collection<String>> getPropertiesList(String key) {
        String property = providerProperties.get(key);
        return StringUtils.isBlank(property) ? Optional.empty()
                : Optional.of(Arrays.stream(property.split("[,]+"))
                .filter(StringUtils::isNotBlank)
                .map(String::trim)
                .collect(Collectors.toList()));
    }


    private Map<String, String> newConfigurationParameters(Map<String, String> providerProperties) {
        String content = providerProperties.get(CONFIGURATION_PARAMETERS);
        if (content == null) {
            return emptyMap();
        }
        try (StringReader reader = new StringReader(content)) {
            Map<String, String> result = new HashMap<>();
            Properties props = new Properties();
            props.load(reader);
            props.stringPropertyNames().forEach(key -> {
                // disable parallel test execution for junit5
                if (!key.equals(PARALLEL_PROP)) {
                    result.put(key, props.getProperty(key));
                }
            });
            return result;
        } catch (IOException e) {
            throw new UncheckedIOException("Error reading " + CONFIGURATION_PARAMETERS, e);
        }
    }


}
