package com.lambdatest.maven.extension;


import com.lambdatest.maven.extension.dependencies.DependencyResolver;
import org.apache.maven.model.Model;
import org.apache.maven.model.Plugin;

import java.util.List;
import java.util.stream.Collectors;

public class MavenConfigurator {

    private final DependencyResolver dependencyResolver;

    private final String framework;

    MavenConfigurator(String framework) {
        this.framework = framework;
        this.dependencyResolver = new DependencyResolver();
    }

    boolean configureTestRunner(Model model) {
        final List<Plugin> effectiveTestRunnerPluginConfigurations = getTestPlugins(model);
        if (!effectiveTestRunnerPluginConfigurations.isEmpty()) {
            effectiveTestRunnerPluginConfigurations
                    .forEach(plugin -> {
                        dependencyResolver.removeConfiguredProviders(plugin);
                        dependencyResolver.addCustomProvider(plugin, this.framework);
                    });
            return true;
        } else {
            return false;
        }
    }

    private List<Plugin> getTestPlugins(Model model) throws IllegalStateException {
        final List<Plugin> testRunnerPluginConfigurations = model.getBuild().getPlugins()
                .stream()
                .filter(
                        plugin -> ApplicablePlugins.contains(plugin.getArtifactId())) // && hasMinimumVersionRequired(plugin, model)
                .collect(Collectors.toList());

        if (testRunnerPluginConfigurations.size() == 0 && isNotPomProject(model)) {
            throw new IllegalStateException("Missing maven test plugin in pom.xml");
        }
//         TODO: check if plugins have testSkipped in them
//         and check for hasMinimumVersionRequired
        return testRunnerPluginConfigurations;
    }

    private boolean isNotPomProject(Model model) {
        return !"pom".equals(model.getPackaging().trim());
    }


}
