package com.lambdatest.maven.extension.dependencies;

import com.lambdatest.runner.api.providers.Provider;
import org.apache.maven.artifact.versioning.*;
import org.apache.maven.model.Dependency;
import org.apache.maven.model.Plugin;

import java.util.List;
import java.util.stream.Collectors;

import static com.lambdatest.runner.api.providers.ProviderList.lookupCustomProvider;
import static com.lambdatest.runner.api.providers.ProviderList.lookupKnownProvider;
import static org.apache.maven.artifact.versioning.VersionRange.createFromVersionSpec;

public class DependencyResolver {

    private static final String MINIMUM_VERSION = "2.19.1";

    public void addCustomProvider(Plugin plugin, String testFramework) {
        Provider provider = getSurefireProvider(plugin.getVersion(), testFramework);
        if (provider == null) throw new RuntimeException("failed to find suitable provider");
        final Dependency customSurefireProvider = new Dependency();
        customSurefireProvider.setGroupId(provider.getGroupId());
        customSurefireProvider.setArtifactId(provider.getFramework());
        customSurefireProvider.setVersion(provider.getVersion());
//        customSurefireProvider.set
        plugin.addDependency(customSurefireProvider);
//        plugin.setConfiguration();
    }

    public void removeConfiguredProviders(Plugin plugin) {
        final List<Dependency> providerDeps = findSurefireProviderDependencies(plugin);
        if (providerDeps.isEmpty()) {
            return;
        }
        for (Dependency dependency : providerDeps) {
            plugin.removeDependency(dependency);
        }
    }

    private List<Dependency> findSurefireProviderDependencies(Plugin plugin) {
        return plugin.getDependencies()
                .stream()
                .map(this::checkIfProviderDepMatches)
                .collect(Collectors.toList());
    }

    private Dependency checkIfProviderDepMatches(Dependency dependency) {
        if (lookupKnownProvider(dependency.getGroupId(), dependency.getArtifactId())) {
            return dependency;
        }
        return null;
    }

    private Provider getSurefireProvider(String surefireVersion, String testFramework) throws RuntimeException {
        ArtifactVersion artifactVersion = new DefaultArtifactVersion(surefireVersion);

        Integer minVersion = artifactVersion.compareTo(new DefaultArtifactVersion(MINIMUM_VERSION));
        if (minVersion < 0) {
            throw new RuntimeException(String.format("Minimum surefire version supported is %s, kindly upgrade in pom.xml", MINIMUM_VERSION));
        }

        if (minVersion == 0) {
            return lookupCustomProvider("surefire-2.19", testFramework);
        }

//        VersionRange range1 = createVersionRange("[2.20, 3.0.0-M3");
//        if (range1.containsVersion(artifactVersion)) {
//            return lookupCustomProvider("surefire-2.22", testFramework);
//        }

        VersionRange range = createVersionRange("[3.0.0-M6,)");
        if (range.containsVersion(artifactVersion)) {
            return lookupCustomProvider("surefire-3.0.0-M7", testFramework);
        }

        if (artifactVersion.compareTo(new DefaultArtifactVersion("3.0.0-M5")) == 0) {
            return lookupCustomProvider("surefire-3.0.0-M5", testFramework);
        }
        if (artifactVersion.compareTo(new DefaultArtifactVersion("3.0.0-M4")) == 0) {
            return lookupCustomProvider("surefire-3.0.0-M4", testFramework);
        }

        return lookupCustomProvider("surefire-2.22", testFramework);
    }

    private VersionRange createVersionRange(String range) {
        try {
            return createFromVersionSpec(range);
        } catch (InvalidVersionSpecificationException e) {
            throw new RuntimeException(e);
        }
    }
}


