package com.lambdatest.maven.extension;

import org.apache.maven.AbstractMavenLifecycleParticipant;
import org.apache.maven.MavenExecutionException;
import org.apache.maven.execution.MavenSession;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.component.annotations.Component;

//TODO: configure logger
@Component(role = AbstractMavenLifecycleParticipant.class, hint = "configurator", description = "Configures our custom surefire providers")
public class PluginExtension extends AbstractMavenLifecycleParticipant {
    @Override
    public void afterSessionStart(MavenSession session)
            throws MavenExecutionException {
    }

    @Override
    public void afterProjectsRead(MavenSession session)
            throws MavenExecutionException {
        session.getAllProjects().forEach(project -> {
            configureMavenProject(project);
        });

    }

    private void configureMavenProject(MavenProject mavenProject) {
        String framework = System.getProperty("framework");
        if (framework == null) throw new RuntimeException("Missing framework");
        final MavenConfigurator mavenProjectConfigurator = new MavenConfigurator(framework);
        Boolean configured = mavenProjectConfigurator.configureTestRunner(mavenProject.getModel());
        if (configured) {
            System.out.printf("Configured: %s\n", mavenProject.getName());
        }
    }
}


