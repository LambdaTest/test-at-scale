package com.lambdatest.surefire.provider;

import static org.apache.maven.surefire.report.SimpleReportEntry.ignored;
import static org.junit.platform.engine.TestExecutionResult.Status.FAILED;


import java.util.Optional;


import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.*;
import com.lambdatest.testrunner.junit5.Junit5Listener;
import org.apache.maven.surefire.report.*;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.TestSource;
import org.junit.platform.engine.support.descriptor.ClassSource;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.TestIdentifier;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.listeners.LegacyReportingUtils;

/**
 * @since 2.22.0
 */
final class Junit5ListenerAdapter extends Junit5Listener {

    private final RunListener runListener;

    private TestPlan testPlan;

    private final Logger logger;


    Junit5ListenerAdapter(RunListener runListener,
                          Logger logger) {
        super(logger);
        this.runListener = runListener;
        this.logger = logger;
    }

    @Override
    public void testPlanExecutionStarted(TestPlan testPlan) {
        updateTestPlan(testPlan);
    }

    @Override
    public void testPlanExecutionFinished(TestPlan testPlan) {
        updateTestPlan(null);
        super.testPlanExecutionFinished(testPlan);
    }

    @Override
    public void dynamicTestRegistered(TestIdentifier testIdentifier) {
    }


    @Override
    public void executionStarted(TestIdentifier testIdentifier) {
        if (testIdentifier.isContainer()
                && testIdentifier.getSource().filter(ClassSource.class::isInstance).isPresent()) {
            super.startSuite(testIdentifier);
            runListener.testSetStarting(createTestSetReportEntry(testIdentifier));
        } else if (testIdentifier.isTest()) {
            super.startTest(testIdentifier);
            runListener.testStarting(createReportEntry(testIdentifier));
        }
    }

    @Override
    public void executionSkipped(TestIdentifier testIdentifier, String reason) {
        String source = getLegacyReportingClassName(testIdentifier);
        runListener.testSkipped(ignored(source, getLegacyReportingName(testIdentifier), reason));
    }

    @Override
    public void executionFinished(
            TestIdentifier testIdentifier, TestExecutionResult testExecutionResult) {

        boolean isClass = testIdentifier.isContainer()
                && testIdentifier.getSource().filter(ClassSource.class::isInstance).isPresent();
        boolean isTest = testIdentifier.isTest();
        boolean failed = testExecutionResult.getStatus() == FAILED;
        boolean isRootContainer = testIdentifier.isContainer() && !testIdentifier.getParentId().isPresent();
        if (failed || isClass || isTest) {
            long endTime = System.currentTimeMillis();
            long elapsed = super.computeElapsedTime(testIdentifier, endTime);
            switch (testExecutionResult.getStatus()) {
                case ABORTED:
                    if (isTest) {
                        super.endTest(elapsed, endTime, Status.failed, null);
                        runListener.testAssumptionFailure(createReportEntry(testIdentifier, testExecutionResult));
                    } else {
                        super.endSuite(elapsed, endTime, Status.failed);
                        runListener.testSetCompleted(createTestSetReportEntry(testIdentifier));
                    }
                    break;
                case FAILED:
                    super.endTest(elapsed, endTime, Status.failed, safeGetMessage(testExecutionResult.getThrowable().orElse(null)));

                    reportFailedTest(testIdentifier, testExecutionResult);
                    if (isClass || isRootContainer) {
                        super.endSuite(elapsed, endTime, Status.failed);
                        runListener.testSetCompleted(createTestSetReportEntry(testIdentifier));

                    }
                    break;
                default:
                    if (isTest) {
                        super.endTest(elapsed, endTime, Status.passed, null);
                        runListener.testSucceeded(createReportEntry(testIdentifier));
                    } else {
                        super.endSuite(elapsed, endTime, Status.passed);
                        runListener.testSetCompleted(createTestSetReportEntry(testIdentifier));
                    }
            }

        }
    }

    private void updateTestPlan(TestPlan testPlan) {
        this.testPlan = testPlan;
    }

    private void reportFailedTest(
            TestIdentifier testIdentifier, TestExecutionResult testExecutionResult) {
        SimpleReportEntry reportEntry = createReportEntry(testIdentifier, testExecutionResult);
        if (testExecutionResult.getThrowable().filter(AssertionError.class::isInstance).isPresent()) {
            runListener.testFailed(reportEntry);
        } else {
            runListener.testError(reportEntry);
        }
    }

    private SimpleReportEntry createTestSetReportEntry(TestIdentifier testIdentifier) {
        return new SimpleReportEntry(
                Junit5ListenerAdapter.class.getName(), testIdentifier.getLegacyReportingName());
    }

    private SimpleReportEntry createReportEntry(TestIdentifier testIdentifier) {
        return createReportEntry(testIdentifier, (StackTraceWriter) null);
    }

    private SimpleReportEntry createReportEntry(
            TestIdentifier testIdentifier, TestExecutionResult testExecutionResult) {
        return createReportEntry(
                testIdentifier, getStackTraceWriter(testIdentifier, testExecutionResult));
    }

    private SimpleReportEntry createReportEntry(
            TestIdentifier testIdentifier, StackTraceWriter stackTraceWriter) {
        String source = getLegacyReportingClassName(testIdentifier);
        String name = getLegacyReportingName(testIdentifier);

        return SimpleReportEntry.withException(source, name, stackTraceWriter);
    }

    private String getLegacyReportingName(TestIdentifier testIdentifier) {
        // Surefire cuts off the name at the first '(' character. Thus, we have to pick a different
        // character to represent parentheses. "()" are removed entirely to maximize compatibility with
        // existing reporting tools because in the old days test methods used to not have parameters.
        return testIdentifier
                .getLegacyReportingName()
                .replace("()", "")
                .replace('(', '{')
                .replace(')', '}');
    }

    private String getLegacyReportingClassName(TestIdentifier testIdentifier) {
        return LegacyReportingUtils.getClassName(testPlan, testIdentifier);
    }

    private StackTraceWriter getStackTraceWriter(
            TestIdentifier testIdentifier, TestExecutionResult testExecutionResult) {
        Optional<Throwable> throwable = testExecutionResult.getThrowable();
        if (testExecutionResult.getStatus() == FAILED) {
            // Failed tests must have a StackTraceWriter, otherwise Surefire will fail
            return getStackTraceWriter(testIdentifier, throwable.orElse(null));
        }
        return throwable.map(t -> getStackTraceWriter(testIdentifier, t)).orElse(null);
    }

    private StackTraceWriter getStackTraceWriter(TestIdentifier testIdentifier, Throwable throwable) {
        String className = getClassName(testIdentifier);
        String methodName = getMethodName(testIdentifier).orElse("");
        return new PojoStackTraceWriter(className, methodName, throwable);
    }

    private String getClassName(TestIdentifier testIdentifier) {
        TestSource testSource = testIdentifier.getSource().orElse(null);
        if (testSource instanceof ClassSource) {
            return ((ClassSource) testSource).getJavaClass().getName();
        }
        if (testSource instanceof MethodSource) {
            return ((MethodSource) testSource).getClassName();
        }
        return testPlan.getParent(testIdentifier).map(this::getClassName).orElse("");
    }

    private Optional<String> getMethodName(TestIdentifier testIdentifier) {
        TestSource testSource = testIdentifier.getSource().orElse(null);
        if (testSource instanceof MethodSource) {
            return Optional.of(((MethodSource) testSource).getMethodName());
        }
        return Optional.empty();
    }

    private String safeGetMessage(Throwable throwable) {
        try {
            SafeThrowable t = throwable == null ? null : new SafeThrowable(throwable);
            return t == null ? null : t.getMessage();
        } catch (Throwable t) {
            return t.getMessage();
        }
    }


}
