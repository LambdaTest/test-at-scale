package com.lambdatest.surefire.provider;

import com.lambdatest.testrunner.junit4.Junit4Recorder;
import org.apache.maven.surefire.api.report.ConsoleOutputReceiver;
import org.apache.maven.surefire.api.report.RunListener;
import org.apache.maven.surefire.api.report.SimpleReportEntry;
import org.apache.maven.surefire.api.report.TestSetReportEntry;
import org.apache.maven.surefire.api.util.internal.ClassMethod;
import org.apache.maven.surefire.common.junit4.JUnit4RunListener;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import java.util.Collections;
import java.util.Map;

import static org.apache.maven.surefire.api.util.internal.ObjectUtils.systemProps;
import static org.apache.maven.surefire.common.junit4.JUnit4ProviderUtil.toClassMethod;

/**
 * A class to be used when there is no JUnit parallelism (methods or/and class). This allow to workaround JUnit
 * limitation a la Junit4 provider. Specifically, we can redirect properly the output even if we don't have class
 * demarcation in JUnit. It works when if there is a JVM instance per test run, i.e. with forkMode=always or perthread.
 */
public class Junit4Listener
        extends JUnit4RunListener
        implements ConsoleOutputReceiver {

    private Description lastFinishedDescription;

    private final Junit4Recorder recorder;


    public Junit4Listener(RunListener reporter,
                          Junit4Recorder recorder)
            throws RuntimeException {
        super(reporter);
        this.recorder = recorder;
    }

    public synchronized void writeTestOutput( String output, boolean newLine, boolean stdout )
    {
        // We can write immediately: no parallelism and a single class.
        ( (ConsoleOutputReceiver) reporter ).writeTestOutput( output, newLine, stdout );
    }
    @Override
    protected SimpleReportEntry createReportEntry( Description description )
    {
        ClassMethod classMethod = toClassMethod( description );
        return new SimpleReportEntry( classMethod.getClazz(), null, classMethod.getMethod(), null );
    }

    private TestSetReportEntry createReportEntryForTestSet( Description description, Map<String, String> systemProps )
    {
        ClassMethod classMethod = toClassMethod( description );
        return new SimpleReportEntry( classMethod.getClazz(), null, null, null, systemProps );
    }

    private TestSetReportEntry createTestSetReportEntryStarted( Description description )
    {
        return createReportEntryForTestSet( description, Collections.<String, String>emptyMap() );
    }

    private TestSetReportEntry createTestSetReportEntryFinished( Description description )
    {
        return createReportEntryForTestSet( description, systemProps() );
    }

    @Override
    public void testStarted(Description description)
            throws Exception {
        finishLastTestSetIfNecessary(description);
        super.testStarted(description);
        recorder.markTestStarted(description);
    }

    private void finishLastTestSetIfNecessary(Description description) {
        if (recorder.describesNewTestSet(description)) {
            recorder.setCurrentTestSetDescription(description);
            if (lastFinishedDescription != null) {
                TestSetReportEntry reportEntry = createTestSetReportEntryFinished(lastFinishedDescription);
                reporter.testSetCompleted(reportEntry);
                lastFinishedDescription = null;
            }
            reporter.testSetStarting(createTestSetReportEntryStarted(description));
        }
    }

    @Override
    public void testFinished(Description description)
            throws Exception {

        super.testFinished(description);
        lastFinishedDescription = description;
        recorder.markTestFinished(description);

    }

    @Override
    public void testIgnored(Description description)
            throws Exception {
        finishLastTestSetIfNecessary(description);
        super.testIgnored(description);
        lastFinishedDescription = description;
        recorder.markTestIgnored(description);
    }

    @Override
    public void testFailure(Failure failure)
            throws Exception {
        finishLastTestSetIfNecessary(failure.getDescription());
        super.testFailure(failure);
        lastFinishedDescription = failure.getDescription();
        recorder.markTestFailed(failure);
    }

    @Override
    public void testAssumptionFailure(Failure failure) {
        super.testAssumptionFailure(failure);
        lastFinishedDescription = failure.getDescription();
        recorder.markTestFailed(failure);
    }

    @Override
    public void testRunStarted(Description description)
            throws Exception {
    }

    @Override
    public void testRunFinished(Result result)
            throws Exception {
        if (lastFinishedDescription != null) {
            reporter.testSetCompleted(createTestSetReportEntryFinished(lastFinishedDescription));
            lastFinishedDescription = null;
        }
        recorder.markTestRunFinished();
    }

}
