package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.TestExecutionObject;
import com.lambdatest.runner.api.models.TestSuiteExecutionObject;
import com.lambdatest.testrunner.testng.TestNGExecutionListener;
import org.apache.maven.surefire.report.CategorizedReportEntry;
import org.apache.maven.surefire.report.PojoStackTraceWriter;
import org.apache.maven.surefire.report.ReportEntry;
import org.apache.maven.surefire.report.RunListener;
import org.apache.maven.surefire.report.SimpleReportEntry;

import org.testng.*;


import static org.apache.maven.surefire.report.SimpleReportEntry.ignored;
import static org.apache.maven.surefire.report.SimpleReportEntry.withException;


public class TestNGReporter
        extends TestNGExecutionListener {
    private final RunListener reporter;

    public TestNGReporter(RunListener reportManager,
                          Logger logger) {
        super(logger);
        this.reporter = reportManager;
    }

    @Override
    public void onTestStart(ITestResult result) {
        String group = groupString(result.getMethod().getGroups(), result.getTestClass().getName());
        String userFriendlyTestName = getUserFriendlyTestName(result);
        reporter.testStarting(new CategorizedReportEntry(getSource(result), userFriendlyTestName, group));
    }

    private String getSource(ITestResult result) {
        return result.getTestClass().getName();
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ReportEntry report = new SimpleReportEntry(getSource(result), getUserFriendlyTestName(result));
        reporter.testSucceeded(report);
        super.onTestSuccess(result);
    }


    @Override
    public void onTestFailure(ITestResult result) {
        ReportEntry report = withException(getSource(result), getUserFriendlyTestName(result),
                new PojoStackTraceWriter(result.getTestClass().getRealClass().getName(),
                        result.getMethod().getMethodName(),
                        result.getThrowable()));

        reporter.testFailed(report);
        super.onTestFailure(result);
    }

    private static String getUserFriendlyTestName(ITestResult result) {
        // This is consistent with the JUnit output
        return result.getName() + "(" + result.getTestClass().getName() + ")";
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        Throwable t = result.getThrowable();
        String reason = t == null ? null : t.getMessage();
        ReportEntry report = ignored(getSource(result), getUserFriendlyTestName(result), reason);
        reporter.testSkipped(report);
        super.onTestSkipped(result);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        ReportEntry report = withException(getSource(result), getUserFriendlyTestName(result),
                new PojoStackTraceWriter(result.getTestClass().getRealClass().getName(),
                        result.getMethod().getMethodName(),
                        result.getThrowable()));
        reporter.testSucceeded(report);
        super.onTestFailedButWithinSuccessPercentage(result);
    }


    @Override
    public void onStart(ITestContext context) {
    }

    @Override
    public void onFinish(ITestContext context) {
    }


    @Override
    public void onStart(ISuite s) {
        super.onStart(s);
    }

    @Override
    public void onFinish(ISuite s) {
        super.onFinish(s);
    }

    /**
     * Creates a string out of the list of testng groups in the
     * form of <pre>"group1,group2,group3"</pre>.
     *
     * @param groups       The groups being run
     * @param defaultValue The default to use if no groups
     * @return a string describing the groups
     */
    private static String groupString(String[] groups, String defaultValue) {
        String retVal;
        if (groups != null && groups.length > 0) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < groups.length; i++) {
                str.append(groups[i]);
                if (i + 1 < groups.length) {
                    str.append(",");
                }
            }
            retVal = str.toString();
        } else {
            retVal = defaultValue;
        }
        return retVal;
    }

    @Override
    public void onConfigurationFailure(ITestResult result) {
        onTestFailure(result);
    }

    @Override
    public void onConfigurationSkip(ITestResult result) {
        onTestSkipped(result);
    }

    @Override
    public void onConfigurationSuccess(ITestResult result) {
        // Don't record configuration successes as separate tests
    }

}
