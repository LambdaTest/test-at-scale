package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.surefire.commons.BaseProvider;
import com.lambdatest.surefire.commons.SurefireLogger;
import com.lambdatest.testrunner.junit4.Junit4Executor;
import com.lambdatest.testrunner.junit4.Junit4Recorder;
import org.apache.maven.surefire.booter.Command;
import org.apache.maven.surefire.booter.CommandReader;
import org.apache.maven.surefire.common.junit48.FilterFactory;
import org.apache.maven.surefire.providerapi.ProviderParameters;
import org.apache.maven.surefire.report.ConsoleOutputCapture;
import org.apache.maven.surefire.report.ConsoleOutputReceiver;
import org.apache.maven.surefire.report.ReporterFactory;
import org.apache.maven.surefire.report.RunListener;
import org.apache.maven.surefire.suite.RunResult;
import org.apache.maven.surefire.testset.TestListResolver;
import org.apache.maven.surefire.testset.TestSetFailedException;
import org.apache.maven.surefire.util.RunOrderCalculator;
import org.apache.maven.surefire.util.ScanResult;
import org.apache.maven.surefire.util.ScannerFilter;
import org.apache.maven.surefire.util.TestsToRun;
import org.junit.runner.manipulation.Filter;

import java.util.Map;

import static org.apache.maven.surefire.booter.CommandReader.getReader;
import static org.apache.maven.surefire.testset.TestListResolver.optionallyWildcardFilter;


public class Junit4Provider extends BaseProvider<RunResult> {

    private final ClassLoader testClassLoader;

    private final ScanResult scanResult;


    private final RunOrderCalculator runOrderCalculator;

    private final ScannerFilter scannerFilter;

    private Logger logger;

    private TestsToRun testsToRun;

    private final Junit4Executor junit4Executor;
    private final RunListener reporter;
    private final ReporterFactory reporterFactory;

    private final TestListResolver testResolver;

    private final Map<String, String> providerProperties;

    private final CommandReader commandsReader;

    private Object forkTestSet;


    public Junit4Provider(ProviderParameters bootParams) {
        commandsReader = bootParams.isInsideFork() ? getReader().setShutdown(bootParams.getShutdown()) : null;
        testClassLoader = bootParams.getTestClassLoader();
        scanResult = bootParams.getScanResult();
        runOrderCalculator = bootParams.getRunOrderCalculator();
        reporterFactory = bootParams.getReporterFactory();
        providerProperties = bootParams.getProviderProperties();
        testResolver = bootParams.getTestRequest().getTestListResolver();
        scannerFilter = new Junit4TestFilter(testClassLoader);
        reporter = reporterFactory.createReporter();
        logger = new SurefireLogger(reporter);
        junit4Executor = new Junit4Executor(logger);
    }

    @Override
    public RunResult invoke(Object forkTestSet) throws TestSetFailedException {
        this.forkTestSet = forkTestSet;
        return super.run();
    }

    @Override
    public TestsToRun scanClassPath() {
        TestsToRun scanned = scanResult.applyFilter(scannerFilter, testClassLoader);
        return runOrderCalculator.orderTestClasses(scanned);
    }


    @Override
    public Iterable<Class<?>> getSuites() {
        if (testsToRun != null) {
            return testsToRun;
        }
        testsToRun = scanClassPath();
        return testsToRun;
    }

    //TODO: Blocklisting tests
    //TODO: Handling for parentSuiteData
    //TODO: disable parallelism


    // mvn test -Dmode=discover -DfailIfNoTests=false -DfailIfNoSpecifiedTests=false
    public RunResult discover() throws TestSetFailedException {
        testsToRun = setTestToRun(forkTestSet, commandsReader, false);
        junit4Executor.discover(testsToRun, createJUnitFilter());
        return RunResult.noTestsRun();
    }

    //    mvn test -Dmode=execute
    public RunResult execute() throws TestSetFailedException {
        final RunResult runResult;
        Junit4Recorder testRecorder = new Junit4Recorder(junit4Executor.getTestResults(), junit4Executor.getSuiteResults());
        Junit4Listener rm = new Junit4Listener(reporter, testRecorder);
        ConsoleOutputCapture.startCapture(rm);
        testsToRun = setTestToRun(forkTestSet, commandsReader, false);
        try {
            junit4Executor.execute(rm, testsToRun, createJUnitFilter());
        } finally {
            runResult = reporterFactory.close();
        }
        return runResult;
    }


    private Filter createJUnitFilter() {
        final FilterFactory factory = new FilterFactory(testClassLoader);
        Filter groupFilter = factory.canCreateGroupFilter(providerProperties) ? factory.createGroupFilter(providerProperties) : null;
        TestListResolver methodFilter = optionallyWildcardFilter(testResolver);
        boolean onlyGroups = methodFilter.isEmpty() || methodFilter.isWildcard();
        if (onlyGroups) {
            return groupFilter;
        } else {
            Filter jUnitMethodFilter = factory.createMethodFilter(methodFilter);
            return groupFilter == null ? jUnitMethodFilter : factory.and(groupFilter, jUnitMethodFilter);
        }

    }

}