package com.lambdatest.surefire.provider;

import org.apache.maven.surefire.common.junit48.JUnit48TestChecker;

public class Junit4TestFilter extends JUnit48TestChecker {
    public Junit4TestFilter(ClassLoader testClsLdr) {
        super(testClsLdr);
    }

    @Override
    public boolean accept(Class aCls) {
        boolean isValidJunitTestCls = super.accept(aCls);

        if (!isValidJunitTestCls && shouldCheckSuperClass(aCls))
            return super.accept(aCls.getSuperclass());

        return isValidJunitTestCls;
    }

    /**
     * We should check super class of {@code aCls} as there are cases when classes just extend
     * real test class by overriding some non-test methods (e.g. #getConfiguration).
     */
    private boolean shouldCheckSuperClass(Class<?> aCls) {
        Class<?> superCls = aCls.getSuperclass();

        return superCls != null && !superCls.equals(Object.class);
    }
}
