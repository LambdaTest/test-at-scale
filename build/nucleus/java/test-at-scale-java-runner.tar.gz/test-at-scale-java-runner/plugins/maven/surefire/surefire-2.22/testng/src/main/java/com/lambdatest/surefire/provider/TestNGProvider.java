package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.ConsoleLogger;
import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.*;
import com.lambdatest.runner.api.request.RequestUtils;
import com.lambdatest.surefire.commons.BaseProvider;
import com.lambdatest.surefire.commons.SurefireLogger;
import com.lambdatest.testrunner.testng.TestNGDirectoryTestSuite;
import com.lambdatest.testrunner.testng.TestNGXmlTestSuite;
import org.apache.maven.surefire.booter.CommandReader;
import org.apache.maven.surefire.providerapi.ProviderParameters;
import org.apache.maven.surefire.report.ConsoleOutputReceiver;
import org.apache.maven.surefire.report.ReporterConfiguration;
import org.apache.maven.surefire.report.ReporterFactory;
import org.apache.maven.surefire.report.RunListener;
import org.apache.maven.surefire.suite.RunResult;
import org.apache.maven.surefire.testset.TestListResolver;
import org.apache.maven.surefire.testset.TestRequest;
import org.apache.maven.surefire.testset.TestSetFailedException;
import org.apache.maven.surefire.util.RunOrderCalculator;
import org.apache.maven.surefire.util.ScanResult;
import org.apache.maven.surefire.util.TestsToRun;

import java.io.File;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.apache.maven.surefire.booter.CommandReader.getReader;
import static org.apache.maven.surefire.report.ConsoleOutputCapture.startCapture;
import static org.apache.maven.surefire.testset.TestListResolver.optionallyWildcardFilter;
import static org.apache.maven.surefire.util.TestsToRun.fromClass;

public class TestNGProvider extends BaseProvider<RunResult> {
    private final Map<String, String> providerProperties;
    private final ClassLoader testClassLoader;

    private final ScanResult scanResult;

    private TestsToRun testsToRun;

    private final TestRequest testRequest;

    private final ReporterConfiguration reporterConfiguration;

    private final RunOrderCalculator runOrderCalculator;

    private final ReporterFactory reporterFactory;

    private final RunListener reporter;

    private Logger logger;

    private final CommandReader commandsReader;

    private Object forkTestSet;


    public TestNGProvider(ProviderParameters bootParams) {
        commandsReader = bootParams.isInsideFork() ? getReader().setShutdown(bootParams.getShutdown()) : null;
        testRequest = bootParams.getTestRequest();
        testClassLoader = bootParams.getTestClassLoader();
        scanResult = bootParams.getScanResult();
        providerProperties = bootParams.getProviderProperties();
        runOrderCalculator = bootParams.getRunOrderCalculator();
        reporterConfiguration = bootParams.getReporterConfiguration();
        reporterFactory = bootParams.getReporterFactory();
        reporter = reporterFactory.createReporter();
        logger = new SurefireLogger(reporter);
    }

    public RunResult invoke(Object forkTestSet) throws TestSetFailedException {
        this.forkTestSet = forkTestSet;
        return super.run();
    }

    public RunResult discover() throws TestSetFailedException {
        if (isTestNGXmlTestSuite(testRequest)) {
            testsToRun = setTestToRun(forkTestSet, commandsReader, true);
            TestNGXmlTestSuite testNGXmlTestSuite = newXmlSuite();
            testNGXmlTestSuite.locateTestSets();
            testNGXmlTestSuite.discover();
        } else {
            testsToRun = setTestToRun(forkTestSet, commandsReader, false);
            TestNGDirectoryTestSuite suite = newDirectorySuite();
            suite.discover();
        }
        return RunResult.noTestsRun();
    }

    public RunResult execute() throws TestSetFailedException {
        RunResult runResult;
        startCapture((ConsoleOutputReceiver) reporter);
        TestSuite testSuite = new TestSuite(providerProperties);
        try {
            if (isTestNGXmlTestSuite(testRequest)) {
                testsToRun = setTestToRun(forkTestSet, commandsReader, true);
                TestNGXmlTestSuite testNGXmlTestSuite = newXmlSuite();
                testNGXmlTestSuite.locateTestSets();
                testSuite.startTestSuite(reporter);
                testNGXmlTestSuite.execute(new TestNGReporter(reporter, logger));
                testSuite.finishTestSuite(reporter);
            } else {
                testsToRun = setTestToRun(forkTestSet, commandsReader, false);
                testSuite.startTestSuite(reporter);
                TestNGDirectoryTestSuite suite = newDirectorySuite();
                suite.execute(testsToRun, new TestNGReporter(reporter, logger));
                testSuite.finishTestSuite(reporter);
            }
        } finally {
            runResult = reporterFactory.close();
        }
        return runResult;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Iterable<Class<?>> getSuites() {
        if (isTestNGXmlTestSuite(testRequest)) {
            return newXmlSuite().locateTestSets();
        } else {
            return scanClassPath();
        }
    }


    private TestNGDirectoryTestSuite newDirectorySuite() {
        return new TestNGDirectoryTestSuite(testsToRun, testRequest.getTestSourceDirectory().toString(), providerProperties,
                reporterConfiguration.getReportsDirectory(), getMethodFilterClassName(), logger);
    }

    private TestNGXmlTestSuite newXmlSuite() {
        return new TestNGXmlTestSuite(testRequest.getSuiteXmlFiles(),
                testRequest.getTestSourceDirectory().toString(),
                providerProperties,
                reporterConfiguration.getReportsDirectory(),
                logger
        );
    }


    @Override
    public TestsToRun scanClassPath() {
        final TestsToRun scanned = scanResult.applyFilter(null, testClassLoader);
        return runOrderCalculator.orderTestClasses(scanned);
    }

    private boolean hasSpecificTests() {
        TestListResolver specificTestPatterns = testRequest.getTestListResolver();
        return !specificTestPatterns.isEmpty() && !specificTestPatterns.isWildcard();
    }


    private boolean isTestNGXmlTestSuite(TestRequest testSuiteDefinition) {
        Collection<File> suiteXmlFiles = testSuiteDefinition.getSuiteXmlFiles();
        return !suiteXmlFiles.isEmpty() && !hasSpecificTests();
    }

    private String getMethodFilterClassName() throws RuntimeException {
        TestListResolver filter = optionallyWildcardFilter(testRequest.getTestListResolver());
        if (filter.isWildcard() || filter.isEmpty()) {
            return null;
        }
        // the class is available in the testClassPath
        String clazzName = "org.apache.maven.surefire.testng.utils.MethodSelector";
        try {
            Class<?> clazz = Class.forName(clazzName);
            Method method = clazz.getMethod("setTestListResolver", TestListResolver.class);
            method.invoke(null, filter);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        return clazzName;
    }


}

//TODO: execution:
//  thread count over method sequential support?
//  commandReader
