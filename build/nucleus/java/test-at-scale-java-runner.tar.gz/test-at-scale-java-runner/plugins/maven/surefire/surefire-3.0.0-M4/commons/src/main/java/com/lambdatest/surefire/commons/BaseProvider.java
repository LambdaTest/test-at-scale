package com.lambdatest.surefire.commons;

import org.apache.maven.surefire.booter.Command;
import org.apache.maven.surefire.booter.CommandListener;
import org.apache.maven.surefire.booter.CommandReader;
import org.apache.maven.surefire.providerapi.AbstractProvider;
import org.apache.maven.surefire.testset.TestSetFailedException;
import org.apache.maven.surefire.util.TestsToRun;

import static com.lambdatest.runner.api.util.Utils.*;
import static org.apache.maven.surefire.util.TestsToRun.fromClass;


public abstract class BaseProvider<T> extends AbstractProvider {
    public abstract T discover() throws TestSetFailedException;

    public abstract T execute() throws TestSetFailedException;

    public abstract TestsToRun scanClassPath();


    public T run() throws TestSetFailedException {
        validateEnv();
        if (IsDiscoveryMode()) {
            return this.discover();
        } else if (IsExecutionMode()) {
            return this.execute();
        } else {
            throw new RuntimeException("Invalid mode provided");
        }
    }

    public final TestsToRun setTestToRun(Object forkTestSet,
                                         CommandReader commandReader,
                                         Boolean isXmlSuite) throws TestSetFailedException {

        // in case of testng xml suite, we only wait for command to be started
        if (isXmlSuite) {
            if (commandReader != null) {
                commandReader.awaitStarted();
            }
            return null;
        }
        TestsToRun testsToRun;
        if (forkTestSet instanceof TestsToRun) {
            testsToRun = (TestsToRun) forkTestSet;
        } else if (forkTestSet instanceof Class) {
            testsToRun = fromClass((Class<?>) forkTestSet);
        } else if (forkTestSet == null) {
            testsToRun = this.scanClassPath();
        } else {
            throw new RuntimeException("Unexpected value of forkTestSet: " + forkTestSet);
        }

        if (commandReader != null) {
            commandReader.awaitStarted();
            registerShutdownListener(commandReader, testsToRun);
        }
        return testsToRun;
    }


    private final void registerShutdownListener(final CommandReader commandsReader,
                                                final TestsToRun testsToRun) {
        commandsReader.addShutdownListener(new CommandListener() {
            @Override
            public void update(Command command) {
                testsToRun.markTestSetFinished();
            }
        });
    }
}