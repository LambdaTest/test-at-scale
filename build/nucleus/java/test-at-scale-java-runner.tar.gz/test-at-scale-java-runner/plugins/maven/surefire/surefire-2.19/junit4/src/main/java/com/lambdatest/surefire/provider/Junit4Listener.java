package com.lambdatest.surefire.provider;

import org.apache.maven.surefire.common.junit4.JUnit4RunListener;
import org.apache.maven.surefire.report.*;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import com.lambdatest.testrunner.junit4.Junit4Recorder;



/**
 * A class to be used when there is no JUnit parallelism (methods or/and class). This allow to workaround JUnit
 * limitation a la Junit4 provider. Specifically, we can redirect properly the output even if we don't have class
 * demarcation in JUnit. It works when if there is a JVM instance per test run, i.e. with forkMode=always or perthread.
 */
public class Junit4Listener
        extends JUnit4RunListener
        implements ConsoleOutputReceiver {

    private Description lastFinishedDescription;

    private final Junit4Recorder recorder;


    public Junit4Listener(RunListener reporter,
                          Junit4Recorder recorder)
            throws RuntimeException {
        super(reporter);
        this.recorder = recorder;
    }

    @Override
    public void writeTestOutput(byte[] buf, int off, int len, boolean stdout) {
        // We can write immediately: no parallelism and a single class.
        ((ConsoleOutputReceiver) reporter).writeTestOutput(buf, off, len, stdout);
    }

    protected SimpleReportEntry createReportEntryForTestSet(Description description) {
        return new SimpleReportEntry(description.getClassName(), description.getClassName());
    }

    @Override
    public void testStarted(Description description)
            throws Exception {
        finishLastTestSetIfNecessary(description);
        super.testStarted(description);
        recorder.markTestStarted(description);
    }

    private void finishLastTestSetIfNecessary(Description description) {
        if (recorder.describesNewTestSet(description)) {
            recorder.setCurrentTestSetDescription(description);
            if (lastFinishedDescription != null) {
                reporter.testSetCompleted(createReportEntryForTestSet(lastFinishedDescription));
                lastFinishedDescription = null;
            }
            reporter.testSetStarting(createReportEntryForTestSet(description));
        }
    }

    @Override
    public void testFinished(Description description)
            throws Exception {

        super.testFinished(description);
        lastFinishedDescription = description;
        recorder.markTestFinished(description);

    }

    @Override
    public void testIgnored(Description description)
            throws Exception {
        finishLastTestSetIfNecessary(description);
        super.testIgnored(description);
        lastFinishedDescription = description;
        recorder.markTestIgnored(description);
    }

    @Override
    public void testFailure(Failure failure)
            throws Exception {
        finishLastTestSetIfNecessary(failure.getDescription());
        super.testFailure(failure);
        lastFinishedDescription = failure.getDescription();
        recorder.markTestFailed(failure);
    }

    @Override
    public void testAssumptionFailure(Failure failure) {
        super.testAssumptionFailure(failure);
        lastFinishedDescription = failure.getDescription();
        recorder.markTestFailed(failure);
    }

    @Override
    public void testRunStarted(Description description)
            throws Exception {
    }

    @Override
    public void testRunFinished(Result result)
            throws Exception {
        if (lastFinishedDescription != null) {
            reporter.testSetCompleted(createReportEntryForTestSet(lastFinishedDescription));
            lastFinishedDescription = null;
        }
        recorder.markTestRunFinished();
    }

}
