package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.surefire.commons.BaseProvider;


import com.lambdatest.surefire.commons.SurefireLogger;
import com.lambdatest.testrunner.junit4.Junit4Executor;
import com.lambdatest.testrunner.junit4.Junit4Recorder;
import org.apache.maven.surefire.api.provider.CommandChainReader;
import org.apache.maven.surefire.api.provider.ProviderParameters;
import org.apache.maven.surefire.api.report.*;
import org.apache.maven.surefire.api.suite.RunResult;
import org.apache.maven.surefire.api.testset.TestListResolver;
import org.apache.maven.surefire.api.testset.TestSetFailedException;
import org.apache.maven.surefire.api.util.RunOrderCalculator;
import org.apache.maven.surefire.api.util.ScanResult;
import org.apache.maven.surefire.api.util.ScannerFilter;
import org.apache.maven.surefire.api.util.TestsToRun;

import static org.apache.maven.surefire.api.report.ConsoleOutputCapture.startCapture;
import static org.apache.maven.surefire.api.report.RunMode.NORMAL_RUN;
import static org.apache.maven.surefire.api.testset.TestListResolver.optionallyWildcardFilter;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

import org.apache.maven.surefire.common.junit48.FilterFactory;
import org.junit.runner.manipulation.Filter;

public class Junit4Provider extends BaseProvider<RunResult> {

    private final ClassLoader testClassLoader;

    private final ScannerFilter scannerFilter;

    private final ReporterFactory reporterFactory;

    private final RunOrderCalculator runOrderCalculator;

    private final ScanResult scanResult;

    private TestsToRun testsToRun;

    private final Junit4Executor junit4Executor;

    private final Logger logger;

    private final TestReportListener<TestOutputReportEntry> reporter;

    private final Map<String, String> providerProperties;

    private final TestListResolver testResolver;

    private final CommandChainReader commandsReader;

    private Object forkTestSet;

    public Junit4Provider(ProviderParameters bootParams) {
        // don't start a thread in CommandReader while we are in in-plugin process
        commandsReader = bootParams.isInsideFork() ? bootParams.getCommandReader() : null;
        testClassLoader = bootParams.getTestClassLoader();
        scanResult = bootParams.getScanResult();
        runOrderCalculator = bootParams.getRunOrderCalculator();
        scannerFilter = new Junit4TestFilter(testClassLoader);
        reporterFactory = bootParams.getReporterFactory();
        reporter = reporterFactory.createTestReportListener();
        logger = new SurefireLogger(reporter);
        junit4Executor = new Junit4Executor(logger);
        providerProperties = bootParams.getProviderProperties();
        testResolver = bootParams.getTestRequest().getTestListResolver();
    }

    @Override
    public RunResult invoke(Object forkTestSet) throws TestSetFailedException, ReporterException, InvocationTargetException {
        this.forkTestSet = forkTestSet;
        return super.run();
    }

    @Override
    public RunResult discover() throws TestSetFailedException {
        testsToRun = setTestToRun(forkTestSet, commandsReader, false);
        junit4Executor.discover(testsToRun, createJUnitFilter());
        return RunResult.noTestsRun();
    }

    @Override
    public RunResult execute() throws TestSetFailedException {
        final RunResult runResult;
        Junit4Recorder testRecorder = new Junit4Recorder(junit4Executor.getTestResults(), junit4Executor.getSuiteResults());
        Junit4Listener listener = new Junit4Listener(reporter, testRecorder);
        listener.setRunMode(NORMAL_RUN);
        // called prior to setTestToRun
        startCapture(listener);
        testsToRun = setTestToRun(forkTestSet, commandsReader, false);
        try {
            junit4Executor.execute(listener, testsToRun, createJUnitFilter());
        } finally {
            runResult = reporterFactory.close();
        }
        return runResult;
    }

    @Override
    public Iterable<Class<?>> getSuites() {
        if (testsToRun != null) {
            return testsToRun;
        }
        testsToRun = scanClassPath();
        return testsToRun;
    }

    @Override
    public TestsToRun scanClassPath() {
        final TestsToRun scannedClasses = scanResult.applyFilter(scannerFilter, testClassLoader);
        return runOrderCalculator.orderTestClasses(scannedClasses);
    }

    private Filter createJUnitFilter() {
        final FilterFactory factory = new FilterFactory(testClassLoader);
        Filter groupFilter = factory.canCreateGroupFilter(providerProperties) ? factory.createGroupFilter(providerProperties) : null;
        TestListResolver methodFilter = optionallyWildcardFilter(testResolver);
        boolean onlyGroups = methodFilter.isEmpty() || methodFilter.isWildcard();
        if (onlyGroups) {
            return groupFilter;
        } else {
            Filter jUnitMethodFilter = factory.createMethodFilter(methodFilter);
            return groupFilter == null ? jUnitMethodFilter : factory.and(groupFilter, jUnitMethodFilter);
        }
    }
}
