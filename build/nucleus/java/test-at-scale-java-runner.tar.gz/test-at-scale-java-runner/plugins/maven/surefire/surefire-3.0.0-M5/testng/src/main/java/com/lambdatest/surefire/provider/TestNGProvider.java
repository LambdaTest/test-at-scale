package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.surefire.commons.BaseProvider;
import com.lambdatest.surefire.commons.SurefireLogger;
import com.lambdatest.testrunner.testng.TestNGDirectoryTestSuite;
import com.lambdatest.testrunner.testng.TestNGXmlTestSuite;
import org.apache.maven.surefire.api.provider.CommandChainReader;
import org.apache.maven.surefire.api.provider.ProviderParameters;
import org.apache.maven.surefire.api.report.ConsoleOutputReceiver;
import org.apache.maven.surefire.api.report.ReporterConfiguration;
import org.apache.maven.surefire.api.report.ReporterFactory;
import org.apache.maven.surefire.api.report.RunListener;
import org.apache.maven.surefire.api.suite.RunResult;
import org.apache.maven.surefire.api.testset.TestListResolver;
import org.apache.maven.surefire.api.testset.TestRequest;
import org.apache.maven.surefire.api.testset.TestSetFailedException;
import org.apache.maven.surefire.api.util.RunOrderCalculator;
import org.apache.maven.surefire.api.util.ScanResult;
import org.apache.maven.surefire.api.util.TestsToRun;

import java.io.File;
import java.lang.reflect.Method;
import java.util.*;

import static org.apache.maven.surefire.api.report.ConsoleOutputCapture.startCapture;
import static org.apache.maven.surefire.api.testset.TestListResolver.optionallyWildcardFilter;

public class TestNGProvider extends BaseProvider<RunResult> {
    private final Map<String, String> providerProperties;
    private final ClassLoader testClassLoader;

    private final ScanResult scanResult;

    private TestsToRun testsToRun;

    private final TestRequest testRequest;

    private final ReporterConfiguration reporterConfiguration;

    private final RunOrderCalculator runOrderCalculator;

    private final ReporterFactory reporterFactory;

    private final RunListener reporter;

    private Logger logger;

    private final CommandChainReader commandsReader;

    private Object forkTestSet;


    public TestNGProvider(ProviderParameters bootParams) {
        commandsReader = bootParams.isInsideFork() ? bootParams.getCommandReader() : null;
        testRequest = bootParams.getTestRequest();
        testClassLoader = bootParams.getTestClassLoader();
        scanResult = bootParams.getScanResult();
        providerProperties = bootParams.getProviderProperties();
        runOrderCalculator = bootParams.getRunOrderCalculator();
        reporterConfiguration = bootParams.getReporterConfiguration();
        reporterFactory = bootParams.getReporterFactory();
        reporter = reporterFactory.createReporter();
        logger = new SurefireLogger(reporter);
    }

    public RunResult invoke(Object forkTestSet) throws TestSetFailedException {
        this.forkTestSet = forkTestSet;
        return super.run();
    }

    public RunResult discover() throws TestSetFailedException {
        if (isTestNGXmlTestSuite(testRequest)) {
            testsToRun = setTestToRun(forkTestSet, commandsReader, true);
            TestNGXmlTestSuite testNGXmlTestSuite = newXmlSuite();
            testNGXmlTestSuite.locateTestSets();
            testNGXmlTestSuite.discover();
        } else {
            testsToRun = setTestToRun(forkTestSet, commandsReader, false);
            TestNGDirectoryTestSuite suite = newDirectorySuite();
            suite.discover();
        }
        return RunResult.noTestsRun();
    }

    public RunResult execute() throws TestSetFailedException {
        RunResult runResult;
        TestSuite testSuite = new TestSuite(providerProperties);
        startCapture((ConsoleOutputReceiver) reporter);
        try {
            TestNGReporter listener = new TestNGReporter(reporter, logger);
            testsToRun = setTestToRun(forkTestSet, commandsReader, true);
            if (isTestNGXmlTestSuite(testRequest)) {
                TestNGXmlTestSuite testNGXmlTestSuite = newXmlSuite();
                testNGXmlTestSuite.locateTestSets();
                testSuite.startTestSuite(reporter);
                testNGXmlTestSuite.execute(listener);
                testSuite.finishTestSuite(reporter);
            } else {
                testsToRun = setTestToRun(forkTestSet, commandsReader, false);
                testSuite.startTestSuite(reporter);
                TestNGDirectoryTestSuite suite = newDirectorySuite();
                suite.execute(testsToRun, listener);
                testSuite.finishTestSuite(reporter);
            }
        } finally {
            runResult = reporterFactory.close();
        }
        return runResult;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Iterable<Class<?>> getSuites() {
        if (isTestNGXmlTestSuite(testRequest)) {
            return newXmlSuite().locateTestSets();
        } else {
            return scanClassPath();
        }
    }


    private TestNGDirectoryTestSuite newDirectorySuite() {
        return new TestNGDirectoryTestSuite(testsToRun, testRequest.getTestSourceDirectory().toString(), providerProperties,
                reporterConfiguration.getReportsDirectory(), getMethodFilterClassName(), logger);
    }

    private TestNGXmlTestSuite newXmlSuite() {
        return new TestNGXmlTestSuite(testRequest.getSuiteXmlFiles(),
                testRequest.getTestSourceDirectory().toString(),
                providerProperties,
                reporterConfiguration.getReportsDirectory(),
                logger
        );
    }

    @Override
    public TestsToRun scanClassPath() {
        final TestsToRun scanned = scanResult.applyFilter(null, testClassLoader);
        return runOrderCalculator.orderTestClasses(scanned);
    }

    private boolean hasSpecificTests() {
        TestListResolver specificTestPatterns = testRequest.getTestListResolver();
        return !specificTestPatterns.isEmpty() && !specificTestPatterns.isWildcard();
    }


    private boolean isTestNGXmlTestSuite(TestRequest testSuiteDefinition) {
        Collection<File> suiteXmlFiles = testSuiteDefinition.getSuiteXmlFiles();
        return !suiteXmlFiles.isEmpty() && !hasSpecificTests();
    }

    private String getMethodFilterClassName() throws RuntimeException {
        TestListResolver filter = optionallyWildcardFilter(testRequest.getTestListResolver());
        if (filter.isWildcard() || filter.isEmpty()) {
            return null;
        }
        // the class is available in the testClassPath
        String clazzName = "org.apache.maven.surefire.testng.utils.MethodSelector";
        try {
            Class<?> clazz = Class.forName(clazzName);
            Method method = clazz.getMethod("setTestListResolver", TestListResolver.class);
            method.invoke(null, filter);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        return clazzName;
    }


}

//TODO: execution:
//  thread count over method sequential support?
//  commandReader
