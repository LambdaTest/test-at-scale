package com.lambdatest.surefire.provider;


import org.apache.maven.surefire.report.ReporterException;
import org.apache.maven.surefire.report.RunListener;
import org.apache.maven.surefire.report.SimpleReportEntry;

import java.util.Map;

import static org.apache.maven.surefire.util.internal.ObjectUtils.systemProps;


public class TestSuite {
    private final Map<String, String> options;

    TestSuite(Map<String, String> options) {
        this.options = options;
    }

    private String getSuiteName() {
        String result = options.get("suitename");
        return result == null ? "TestSuite" : result;
    }

    final void startTestSuite(RunListener reporterManager) {
        try {
            reporterManager.testSetStarting(
                    new SimpleReportEntry(getClass().getName(), getSuiteName(), systemProps()));
        } catch (ReporterException e) {
            // TODO: remove this exception from the report manager
        }
    }

    final void finishTestSuite(RunListener reporterManager) {
        reporterManager.testSetCompleted(
                new SimpleReportEntry(getClass().getName(), getSuiteName(), systemProps()));
    }
}
