package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.testrunner.testng.TestNGExecutionListener;
import org.apache.maven.surefire.api.report.*;
import org.apache.maven.surefire.report.ClassMethodIndexer;
import org.apache.maven.surefire.report.PojoStackTraceWriter;

import org.apache.maven.surefire.report.RunModeSetter;
import org.testng.*;

import java.util.Arrays;

import static org.apache.maven.surefire.api.report.SimpleReportEntry.ignored;
import static org.apache.maven.surefire.api.report.SimpleReportEntry.withException;


public class TestNGReporter
        extends TestNGExecutionListener
        implements TestOutputReceiver<OutputReportEntry>, RunModeSetter {

    private final ClassMethodIndexer classMethodIndexer = new ClassMethodIndexer();
    private volatile RunMode runMode;

    private final TestReportListener<TestOutputReportEntry> reporter;

    public TestNGReporter(TestReportListener<TestOutputReportEntry> reportManager,
                          Logger logger) {
        super(logger);
        this.reporter = reportManager;
    }

    @Override
    public void onTestStart(ITestResult result) {
        String className = result.getTestClass().getName();
        String methodName = testName(result);
        long testRunId = classMethodIndexer.indexClassMethod(className, methodName);
        String group = groupString(result.getMethod().getGroups(), className);
        reporter.testStarting(new CategorizedReportEntry(runMode, testRunId, className, methodName, group));
    }

    private String getSource(ITestResult result) {
        return result.getTestClass().getName();
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        IClass clazz = result.getTestClass();
        String className = clazz.getName();
        String methodName = testName(result);
        long testRunId = classMethodIndexer.indexClassMethod(className, methodName);
        ReportEntry report = new SimpleReportEntry( runMode, testRunId, className, null, methodName, null );
        reporter.testSucceeded( report );
        super.onTestSuccess(result);
    }


    @Override
    public void onTestFailure(ITestResult result) {
        IClass clazz = result.getTestClass();
        String className = clazz.getName();
        String methodName = testName(result);
        long testRunId = classMethodIndexer.indexClassMethod(className, methodName);
        StackTraceWriter stackTraceWriter = new PojoStackTraceWriter(clazz.getRealClass().getName(),
                result.getMethod().getMethodName(), result.getThrowable());
        ReportEntry report = withException(runMode, testRunId, clazz.getName(), null, methodName,
                null, stackTraceWriter);

        reporter.testFailed(report);
        super.onTestFailure(result);
    }

    private static String getUserFriendlyTestName(ITestResult result) {
        // This is consistent with the JUnit output
        return result.getName() + "(" + result.getTestClass().getName() + ")";
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String className = result.getTestClass().getName();
        String methodName = testName(result);
        long testRunId = classMethodIndexer.indexClassMethod(className, methodName);
        //noinspection ThrowableResultOfMethodCallIgnored
        Throwable t = result.getThrowable();
        String reason = t == null ? null : t.getMessage();
        ReportEntry report = ignored(runMode, testRunId, className, null, methodName, null, reason);
        reporter.testSkipped(report);
        super.onTestSkipped(result);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        IClass clazz = result.getTestClass();
        String className = clazz.getName();
        String methodName = testName(result);
        long testRunId = classMethodIndexer.indexClassMethod(className, methodName);
        StackTraceWriter stackTraceWriter = new PojoStackTraceWriter(clazz.getRealClass().getName(),
                result.getMethod().getMethodName(), result.getThrowable());
        ReportEntry report = withException(runMode, testRunId, className, null, methodName, null, stackTraceWriter);
        reporter.testSucceeded(report);
        super.onTestFailedButWithinSuccessPercentage(result);
    }


    @Override
    public void onStart(ITestContext context) {
    }

    @Override
    public void onFinish(ITestContext context) {
    }


    @Override
    public void onStart(ISuite s) {
        super.onStart(s);
    }

    @Override
    public void onFinish(ISuite s) {
        super.onFinish(s);
    }

    /**
     * Creates a string out of the list of testng groups in the
     * form of <pre>"group1,group2,group3"</pre>.
     *
     * @param groups       The groups being run
     * @param defaultValue The default to use if no groups
     * @return a string describing the groups
     */
    private static String groupString(String[] groups, String defaultValue) {
        String retVal;
        if (groups != null && groups.length > 0) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < groups.length; i++) {
                str.append(groups[i]);
                if (i + 1 < groups.length) {
                    str.append(",");
                }
            }
            retVal = str.toString();
        } else {
            retVal = defaultValue;
        }
        return retVal;
    }

    @Override
    public void onConfigurationFailure(ITestResult result) {
        onTestFailure(result);
    }

    @Override
    public void onConfigurationSkip(ITestResult result) {
        onTestSkipped(result);
    }

    @Override
    public void onConfigurationSuccess(ITestResult result) {
        // Don't record configuration successes as separate tests
    }


    private static String testName(ITestResult result) {
        Object[] parameters = result.getParameters();
        String name = result.getName();
        return parameters == null || parameters.length == 0
                ? name : name + Arrays.toString(parameters) + "(" + result.getMethod().getCurrentInvocationCount() + ")";
    }

    @Override
    public void setRunMode(RunMode runMode) {
        this.runMode = runMode;
    }

    @Override
    public void writeTestOutput(OutputReportEntry reportEntry) {
        Long testRunId = classMethodIndexer.getLocalIndex();
        reporter.writeTestOutput(new TestOutputReportEntry(reportEntry, runMode, testRunId));
    }

}
