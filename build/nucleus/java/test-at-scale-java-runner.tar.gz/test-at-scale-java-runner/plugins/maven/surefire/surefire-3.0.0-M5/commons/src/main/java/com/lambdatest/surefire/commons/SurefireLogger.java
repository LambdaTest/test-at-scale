package com.lambdatest.surefire.commons;

import com.lambdatest.runner.api.logger.Logger;
import org.apache.maven.plugin.surefire.log.api.ConsoleLogger;
import org.apache.maven.plugin.surefire.log.api.PrintStreamLogger;
import org.apache.maven.surefire.api.report.RunListener;

public class SurefireLogger implements Logger {

    private final ConsoleLogger consoleLogger;

    public SurefireLogger(RunListener reporter) {
        consoleLogger = (reporter instanceof ConsoleLogger)
                ? (ConsoleLogger) reporter : new PrintStreamLogger(System.out);

    }

    public void debug(String format, Object... args) {
        consoleLogger.debug(String.format(format, args));
    }

    public void info(String format, Object... args) {
        consoleLogger.info(String.format(format, args));
    }

    public void warn(String format, Object... args) {
        consoleLogger.warning(String.format(format, args));
    }

    public void error(String format, Object... args) {
        consoleLogger.error(String.format(format, args));
    }


}
