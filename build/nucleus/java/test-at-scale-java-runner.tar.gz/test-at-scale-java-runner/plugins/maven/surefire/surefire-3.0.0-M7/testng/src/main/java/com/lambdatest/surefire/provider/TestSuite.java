package com.lambdatest.surefire.provider;


import org.apache.maven.surefire.api.report.ReporterException;
import org.apache.maven.surefire.api.report.RunListener;
import org.apache.maven.surefire.api.report.SimpleReportEntry;


import java.util.Map;

import static org.apache.maven.surefire.api.report.RunMode.NORMAL_RUN;
import static org.apache.maven.surefire.api.util.internal.ObjectUtils.systemProps;


public class TestSuite {
    private final Map<String, String> options;

    TestSuite(Map<String, String> options) {
        this.options = options;
    }

    private String getSuiteName() {
        String result = options.get("suitename");
        return result == null ? "TestSuite" : result;
    }

    final void startTestSuite(RunListener reporterManager) {
        try {
            reporterManager.testSetStarting(
                    new SimpleReportEntry(NORMAL_RUN, 0L, getSuiteName(), null, null, null));
        } catch (ReporterException e) {
            // TODO: remove this exception from the report manager
        }
    }

    final void finishTestSuite(RunListener reporterManager) {
        reporterManager.testSetCompleted(
                new SimpleReportEntry(NORMAL_RUN, 0L, getSuiteName(), null, null, null, systemProps()));
    }
}
