package com.lambdatest.surefire.provider;

import com.lambdatest.testrunner.junit5.Junit5Scanner;
import org.apache.maven.surefire.api.util.ScannerFilter;
import org.junit.platform.engine.Filter;
import org.junit.platform.launcher.Launcher;

class Junit5TestScanner extends Junit5Scanner implements ScannerFilter {

    Junit5TestScanner(Launcher launcher, Filter<?>[] includeAndExcludeFilters) {
        super(launcher, includeAndExcludeFilters);

    }


    @Override
    @SuppressWarnings("rawtypes")
    public boolean accept(Class testClass) {
        return super.accept(testClass);
    }
}
