package com.lambdatest.surefire.provider;

import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.surefire.commons.BaseProvider;
import com.lambdatest.surefire.commons.SurefireLogger;
import com.lambdatest.testrunner.junit5.Junit5Executor;
import com.lambdatest.testrunner.junit5.Junit5TestMethodFilter;
import com.lambdatest.testrunner.junit5.LazyLauncher;
import org.apache.commons.lang3.StringUtils;
import org.apache.maven.surefire.booter.CommandReader;
import org.apache.maven.surefire.providerapi.ProviderParameters;
import org.apache.maven.surefire.report.ConsoleOutputCapture;
import org.apache.maven.surefire.report.ConsoleOutputReceiver;
import org.apache.maven.surefire.report.ReporterFactory;
import org.apache.maven.surefire.report.RunListener;
import org.apache.maven.surefire.suite.RunResult;
import org.apache.maven.surefire.testset.TestListResolver;
import org.apache.maven.surefire.testset.TestSetFailedException;
import org.apache.maven.surefire.util.ScanResult;
import org.apache.maven.surefire.util.SurefireReflectionException;
import org.apache.maven.surefire.util.TestsToRun;

import java.util.Map;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.stream.Collectors;

import org.junit.platform.engine.Filter;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.PostDiscoveryFilter;
import org.junit.platform.launcher.TagFilter;

import static org.apache.maven.surefire.booter.CommandReader.getReader;
import static org.apache.maven.surefire.booter.ProviderParameterNames.TESTNG_EXCLUDEDGROUPS_PROP;
import static org.apache.maven.surefire.booter.ProviderParameterNames.TESTNG_GROUPS_PROP;

import static org.apache.maven.surefire.testset.TestListResolver.optionallyWildcardFilter;


public class Junit5Provider extends BaseProvider<RunResult> {

    private final ProviderParameters parameters;
    private final Launcher launcher;

    private TestsToRun testsToRun;

    private Logger logger;

    private final Junit5Executor junit5Executor;

    private final TestListResolver testListResolver;

    private final Map<String, String> providerProperties;

    private final Filter<?>[] filters;

    private final ReporterFactory reporterFactory;
    private final RunListener reporter;

    private Object forkTestSet;

    private final CommandReader commandsReader;


    @SuppressWarnings("unused")
    public Junit5Provider(ProviderParameters parameters) {
        this(parameters, new LazyLauncher());
    }


    Junit5Provider(ProviderParameters parameters, Launcher launcher) {
        this.parameters = parameters;
        this.launcher = launcher;
        commandsReader = parameters.isInsideFork() ? getReader().setShutdown(parameters.getShutdown()) : null;
        //TODO: remove parallel tests if provided
        providerProperties = parameters.getProviderProperties();
        reporterFactory = parameters.getReporterFactory();
        reporter = reporterFactory.createReporter();
        testListResolver = parameters.getTestRequest().getTestListResolver();
        filters = newFilters();
        logger = new SurefireLogger(reporter);
        junit5Executor = new Junit5Executor(logger, filters, providerProperties);
    }

    @Override
    public RunResult invoke(Object forkTestSet) throws TestSetFailedException {
        this.forkTestSet = forkTestSet;
        return super.run();
    }

    @Override
    public Iterable<Class<?>> getSuites() {
        try {
            return scanClassPath();
        } finally {
            closeLauncher();
        }
    }

    public RunResult execute() throws TestSetFailedException {
        RunResult runResult;
        Junit5ListenerAdapter listener = new Junit5ListenerAdapter(reporter, logger);
        try {
            ConsoleOutputCapture.startCapture((ConsoleOutputReceiver) reporter);
            testsToRun = setTestToRun(forkTestSet, commandsReader, false);
            junit5Executor.execute(launcher, testsToRun, listener);
        } finally {
            runResult = reporterFactory.close();
        }
        return runResult;
    }

    public RunResult discover() throws TestSetFailedException {
        testsToRun = setTestToRun(forkTestSet, commandsReader, false);
        junit5Executor.discover(launcher, testsToRun);
        return RunResult.noTestsRun();
    }


    private void closeLauncher() {
        if (launcher instanceof AutoCloseable) {
            try {
                ((AutoCloseable) launcher).close();
            } catch (Exception e) {
                throw new SurefireReflectionException(e);
            }
        }
    }

    private Filter<?>[] newFilters() {
        List<Filter<?>> filters = new ArrayList<>();

        getPropertiesList(TESTNG_GROUPS_PROP)
                .map(TagFilter::includeTags)
                .ifPresent(filters::add);

        getPropertiesList(TESTNG_EXCLUDEDGROUPS_PROP)
                .map(TagFilter::excludeTags)
                .ifPresent(filters::add);

        Optional<TestListResolver> filter = Optional.of(optionallyWildcardFilter(this.testListResolver))
                .filter(f -> !f.isEmpty())
                .filter(f -> !f.isWildcard());

        if (filter.isPresent()) {
            PostDiscoveryFilter methodFilter = new Junit5TestMethodFilter(this::shouldRun);
            filters.add(methodFilter);
        }

        return filters.toArray(new Filter<?>[filters.size()]);
    }


    private Optional<List<String>> getPropertiesList(String key) {
        String property = parameters.getProviderProperties().get(key);
        return StringUtils.isBlank(property) ? Optional.empty()
                : Optional.of(Arrays.stream(property.split("[,]+"))
                .filter(StringUtils::isNotBlank)
                .map(String::trim)
                .collect(Collectors.toList()));
    }

    @Override
    public TestsToRun scanClassPath() {
        Junit5TestScanner filter = new Junit5TestScanner(launcher, filters);
        ScanResult scanResult = parameters.getScanResult();
        TestsToRun scannedClasses = scanResult.applyFilter(filter, parameters.getTestClassLoader());
        return parameters.getRunOrderCalculator().orderTestClasses(scannedClasses);
    }

    private boolean shouldRun(MethodSource source) {
        String testClass = TestListResolver.toClassFileName(source.getClassName());
        String testMethod = source.getMethodName();
        return this.testListResolver.shouldRun(testClass, testMethod);
    }

}
