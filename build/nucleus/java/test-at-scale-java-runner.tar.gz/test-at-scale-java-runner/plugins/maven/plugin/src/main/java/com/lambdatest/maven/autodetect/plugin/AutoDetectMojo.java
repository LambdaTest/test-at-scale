package com.lambdatest.maven.autodetect.plugin;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.artifact.versioning.DefaultArtifactVersion;
import org.apache.maven.artifact.versioning.InvalidVersionSpecificationException;
import org.apache.maven.artifact.versioning.OverConstrainedVersionException;
import org.apache.maven.artifact.versioning.VersionRange;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.project.MavenProject;
import org.apache.maven.plugins.annotations.Component;
import org.codehaus.plexus.logging.Logger;

import java.util.Map;

import static org.apache.maven.artifact.versioning.VersionRange.createFromVersionSpec;

@Mojo(name = "detect", defaultPhase = LifecyclePhase.TEST_COMPILE, threadSafe = true,
        requiresDependencyResolution = ResolutionScope.TEST)
public class AutoDetectMojo extends AbstractMojo {
    /**
     * The Maven Project Object.
     */
    @Parameter(defaultValue = "${project}", required = true, readonly = true)
    private MavenProject project;

    /**
     * Map of plugin artifacts.
     */
    @Parameter(property = "plugin.artifactMap", required = true, readonly = true)
    private Map<String, Artifact> pluginArtifactMap;

    /**
     *
     */

    /**
     * Allows you to specify the name of the JUnit artifact. If not set, {@code junit:junit} will be used.
     *
     * @since 2.3.1
     */
    @Parameter(property = "junitArtifactName", defaultValue = "junit:junit")
    private String junitArtifactName;

    /**
     * Allows you to specify the name of the JUnit Platform artifact.
     * If not set, {@code org.junit.platform:junit-platform-engine} will be used.
     *
     * @since 2.22.0
     */
    @Parameter(property = "junitPlatformArtifactName", defaultValue = "org.junit.platform:junit-platform-engine")
    private String junitPlatformArtifactName;

    /**
     * Allows you to specify the name of the TestNG artifact. If not set, {@code org.testng:testng} will be used.
     *
     * @since 2.3.1
     */
    @Parameter(property = "testNGArtifactName", defaultValue = "org.testng:testng")
    private String testNGArtifactName;


    /**
     * Map of project artifacts.
     */
    @Parameter(property = "project.artifactMap", readonly = true, required = true)
    private Map<String, Artifact> projectArtifactMap;

    @Component
    private Logger logger;

    public Map<String, Artifact> getProjectArtifactMap() {
        return projectArtifactMap;
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setProjectArtifactMap(Map<String, Artifact> projectArtifactMap) {
        this.projectArtifactMap = projectArtifactMap;
    }

    public Map<String, Artifact> getPluginArtifactMap() {
        return pluginArtifactMap;
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setPluginArtifactMap(Map<String, Artifact> projectArtifactMap) {
        this.pluginArtifactMap = projectArtifactMap;
    }

    public String getJunitArtifactName() {
        return junitArtifactName;
    }

    public String getJunitPlatformArtifactName() {
        return junitPlatformArtifactName;
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setJunitPlatformArtifactName(String junitPlatformArtifactName) {
        this.junitPlatformArtifactName = junitPlatformArtifactName;
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setJunitArtifactName(String junitArtifactName) {
        this.junitArtifactName = junitArtifactName;
    }

    public String getTestNGArtifactName() {
        return testNGArtifactName;
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setTestNGArtifactName(String testNGArtifactName) {
        this.testNGArtifactName = testNGArtifactName;
    }

    private Artifact getJunitArtifact() {
        Artifact artifact = getProjectArtifactMap().get(getJunitArtifactName());
        Artifact projectArtifact = project.getArtifact();
        String projectArtifactName = projectArtifact.getGroupId() + ":" + projectArtifact.getArtifactId();

        if (artifact == null && projectArtifactName.equals(getJunitArtifactName())) {
            artifact = projectArtifact;
        }

        return artifact;
    }

    private Artifact getJunitDepArtifact() {
        return getProjectArtifactMap().get("junit:junit-dep");
    }

    private Artifact getTestNgArtifact()
            throws MojoExecutionException {
        Artifact artifact = getProjectArtifactMap().get(getTestNGArtifactName());
        Artifact projectArtifact = project.getArtifact();
        String projectArtifactName = projectArtifact.getGroupId() + ":" + projectArtifact.getArtifactId();

        if (artifact != null) {
            VersionRange range = createVersionRange();
            if (!range.containsVersion(new DefaultArtifactVersion(artifact.getVersion()))) {
                throw new MojoExecutionException(
                        "TestNG support requires version 4.7 or above. You have declared version "
                                + artifact.getVersion());
            }
        } else if (projectArtifactName.equals(getTestNGArtifactName())) {
            artifact = projectArtifact;
        }

        return artifact;
    }

    private VersionRange createVersionRange() {
        try {
            return createFromVersionSpec("[4.7,)");
        } catch (InvalidVersionSpecificationException e) {
            throw new RuntimeException(e);
        }
    }

    static boolean isWithinVersionSpec(Artifact artifact, String versionSpec) {
        if (artifact == null) {
            return false;
        }
        try {
            VersionRange range = createFromVersionSpec(versionSpec);
            try {
                return range.containsVersion(artifact.getSelectedVersion());
            } catch (NullPointerException e) {
                return range.containsVersion(new DefaultArtifactVersion(artifact.getBaseVersion()));
            }
        } catch (InvalidVersionSpecificationException | OverConstrainedVersionException e) {
            throw new RuntimeException("Bug in plugin. Please report with stacktrace");
        }
    }

    private Artifact getJUnitPlatformRunnerArtifact() {
        return getProjectArtifactMap().get("org.junit.platform:junit-platform-runner");
    }

    private Artifact getJUnit5Artifact() {
        Artifact artifact = getPluginArtifactMap().get(getJunitPlatformArtifactName());
        if (artifact == null) {
            return getProjectArtifactMap().get("org.junit.platform:junit-platform-commons");
        }

        return artifact;
    }

    private boolean isJunit47Compatible(Artifact artifact) {
        return isWithinVersionSpec(artifact, "[4.7,)");
    }

    private boolean isAnyJunit4(Artifact artifact) {
        return isWithinVersionSpec(artifact, "[4.0,)");
    }


    @Override
    public void execute()
            throws MojoExecutionException {

        Artifact junitDepArtifact = getJunitDepArtifact();

//        TODO: handling for junit [4.7,)
        if (getTestNgArtifact() != null) {
            logger.info("Is TestNG");
        } else if (getJUnitPlatformRunnerArtifact() == null && getJUnit5Artifact() != null) {
            logger.info("Is Junit5");
        } else if (junitDepArtifact != null || isAnyJunit4(getJunitArtifact())) {
            logger.info("Is Junit4");
        } else {
            logger.info("Is Junit3");
        }
    }

}

