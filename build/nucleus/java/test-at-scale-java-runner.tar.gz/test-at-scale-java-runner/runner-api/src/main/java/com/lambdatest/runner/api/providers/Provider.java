package com.lambdatest.runner.api.providers;

import lombok.Data;
import lombok.NonNull;


@Data
public class Provider {
    @NonNull
    private String groupId;
    @NonNull
    private String framework;

    @NonNull
    private String version;
}
