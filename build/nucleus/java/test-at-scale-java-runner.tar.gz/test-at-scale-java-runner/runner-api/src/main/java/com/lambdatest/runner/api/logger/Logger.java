package com.lambdatest.runner.api.logger;

public interface Logger {


    void debug(String format, Object... args);

    void info(String format, Object... args);

    void warn(String format, Object... args);

    void error(String format, Object... args);
}
