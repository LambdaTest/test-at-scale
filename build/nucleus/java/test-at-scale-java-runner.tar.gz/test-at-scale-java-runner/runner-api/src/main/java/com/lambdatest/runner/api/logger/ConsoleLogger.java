package com.lambdatest.runner.api.logger;

/**
 * {@link Logger} implementation which logs to {@code System.out}.
 */
public class ConsoleLogger implements Logger {
    private final boolean verbose;

    public ConsoleLogger(boolean verbose) {
        this.verbose = verbose;
    }

    public void info(String format, Object... args) {
        if (verbose) {
            System.out.format(format, args);
            System.out.println();
        }
    }
    public void error(String format, Object... args) {
        System.out.format(format, args);
        System.out.println();
    }
    public void warn(String format, Object... args) {
        System.out.format(format, args);
        System.out.println();
    }
    public void debug(String format, Object... args) {
        if (verbose) {
            System.out.format(format, args);
            System.out.println();
        }
    }
}