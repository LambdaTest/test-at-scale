package com.lambdatest.runner.api.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionUtils {

    private ReflectionUtils() {
        throw new IllegalStateException("no instantiable constructor");
    }

    public static Method getMethod(Object instance, String methodName, Class<?>... parameters) {
        return getMethod(instance.getClass(), methodName, parameters);
    }

    public static Method getMethod(Class<?> clazz, String methodName, Class<?>... parameters) {
        try {
            return clazz.getMethod(methodName, parameters);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("When finding method " + methodName, e);
        }
    }


    @SuppressWarnings("checkstyle:emptyblock")
    public static Class<?> tryLoadClass(ClassLoader classLoader, String className) {
        try {
            return classLoader.loadClass(className);
        } catch (NoClassDefFoundError | ClassNotFoundException ignore) {
        }
        return null;
    }

    public static Class<?> loadClass(ClassLoader classLoader, String className) {
        try {
            return classLoader.loadClass(className);
        } catch (NoClassDefFoundError | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public static void invokeSetter(Object o, String name, Class<?> value1clazz, Object value) {
        Method setter = getMethod(o, name, value1clazz);
        invokeSetter(o, setter, value);
    }

    public static <T> T invokeSetter(Object target, Method method, Object value) {
        return invokeMethodWithArray(target, method, value);
    }

    public static <T> T invokeGetter( Object instance, String methodName )
    {
        return invokeGetter( instance.getClass(), instance, methodName );
    }

    public static <T> T invokeGetter( Class<?> instanceType, Object instance, String methodName )
    {
        Method method = getMethod( instanceType, methodName );
        return invokeMethodWithArray( instance, method );
    }

    public static <T> T invokeMethodWithArray(Object target, Method method, Object... args) {
        try {
            //noinspection unchecked
            return (T) method.invoke(target, args);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e.getTargetException());
        }
    }


}
