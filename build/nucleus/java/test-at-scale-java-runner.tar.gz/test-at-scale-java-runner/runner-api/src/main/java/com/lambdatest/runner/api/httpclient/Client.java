package com.lambdatest.runner.api.httpclient;

import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

public class Client {

    private CloseableHttpClient httpclient = HttpClients.createDefault();

    int CONNECTION_TIMEOUT_MS = 45 * 1000; // Timeout in millis.

    public Client(){
        httpclient = HttpClients.createDefault();
    }

    RequestConfig defaultRequestConfig = RequestConfig.custom()
            .setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
            .setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
            .setSocketTimeout(CONNECTION_TIMEOUT_MS)
            .build();


    public String sendPost(String url, String requestBody) throws RuntimeException {
        url = url.trim();
        CloseableHttpResponse response = null;
        HttpPost request = null;

        try {
            request = new HttpPost(url);
            request.addHeader("Content-Type", "application/json");
            request.setConfig(defaultRequestConfig);

            request.setEntity(new StringEntity(requestBody));
            response = httpclient.execute(request);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                return EntityUtils.toString(response.getEntity());
            } else {
                throw new RuntimeException("requestPost remote error, request : " + url + ", statusCode=" + statusCode
                        + ";" + EntityUtils.toString(response.getEntity()));
            }
        } catch (Throwable t) {
            throw new RuntimeException("requestPost remote error, request : " + url, t);
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    // ignore
                }
            }
            if (request != null) {
                request.releaseConnection();
            }
        }
    }
}
