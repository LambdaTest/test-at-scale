package com.lambdatest.runner.api.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lambdatest.runner.api.util.Utils;
import lombok.Builder;
import lombok.Data;

import java.util.Collection;
import java.util.List;

@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExecutionResultObject {

    private final String repoID = Utils.RepoID;

    private final String commitID = Utils.CommitID;

    private final String buildID = Utils.BuildID;

    private final String taskID = Utils.TaskID;

    private final String orgID = Utils.OrgID;

    private List<Result> results;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Builder
    @Data
    public static class Result {
        private Collection<TestExecutionObject> testResults;
        private Collection<TestSuiteExecutionObject> testSuiteResults;
    }

    public String buildRequestBody() {
        String strBody;
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        try {
            strBody = objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return strBody;
    }

}
