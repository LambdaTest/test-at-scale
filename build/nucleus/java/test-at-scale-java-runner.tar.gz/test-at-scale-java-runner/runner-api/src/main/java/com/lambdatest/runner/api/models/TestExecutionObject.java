package com.lambdatest.runner.api.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestExecutionObject extends TestObject {
    Status status;
    long duration;
    String failureMessage;
    String start_time;
    String end_time;

    @Builder(builderMethodName = "childBuilder")
    public TestExecutionObject(String testID, String testName,
                               String title, String filepath,
                               String suiteID,
                               String locator, String className,
                               Status status, long duration,
                               String start_time, String end_time,
                               String failureMessage) {
        super(testID, testName, title, filepath, suiteID, locator, className);
        this.status = status;
        this.duration = duration;
        this.start_time = start_time;
        this.end_time = end_time;
        this.failureMessage = failureMessage;
    }
}