package com.lambdatest.runner.api.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import lombok.experimental.SuperBuilder;

@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestObject {
    @NonNull
    String testID;
    String testName;
    String title;
    String filepath;
    String suiteID;
    String locator;
    String className;



}
