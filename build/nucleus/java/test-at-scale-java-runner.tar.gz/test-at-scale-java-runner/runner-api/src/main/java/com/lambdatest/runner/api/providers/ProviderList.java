package com.lambdatest.runner.api.providers;

import org.apache.commons.collections4.map.MultiKeyMap;

public class ProviderList {
    private static MultiKeyMap knownProviders = new MultiKeyMap();

    private static MultiKeyMap customProviders = new MultiKeyMap();

    private static final String ProviderVersion = "1.0-SNAPSHOT";

    private static void initKnownProviders() {
        knownProviders.put("org.apache.maven.surefire", "surefire-junit4", true);
        knownProviders.put("org.apache.maven.surefire", "surefire-junit47", true);
        knownProviders.put("org.apache.maven.surefire", "surefire-junit-platform", true);
        knownProviders.put("org.apache.maven.surefire", "surefire-testng", true);
        knownProviders.put("org.junit.platform", "junit-platform-surefire-provider", true);
    }

    private static void initCustomProviders() {
//        TODO: find way to read module version
        customProviders.put("surefire-2.19", "junit4", new Provider("com.lambdatest.surefire-2.19", "junit4", ProviderVersion));
        customProviders.put("surefire-2.19", "testng", new Provider("com.lambdatest.surefire-2.19", "testng", ProviderVersion));

        customProviders.put("surefire-2.22", "junit4", new Provider("com.lambdatest.surefire-2.22", "junit4", ProviderVersion));
        customProviders.put("surefire-2.22", "testng", new Provider("com.lambdatest.surefire-2.22", "testng", ProviderVersion));
        customProviders.put("surefire-2.22", "junit5", new Provider("com.lambdatest.surefire-2.22", "junit5", ProviderVersion));

        customProviders.put("surefire-3.0.0-M4", "junit4", new Provider("com.lambdatest.surefire-3.0.0-M4", "junit4", ProviderVersion));
        customProviders.put("surefire-3.0.0-M4", "testng", new Provider("com.lambdatest.surefire-3.0.0-M4", "testng", ProviderVersion));
        customProviders.put("surefire-3.0.0-M4", "junit5", new Provider("com.lambdatest.surefire-3.0.0-M4", "junit5", ProviderVersion));

        customProviders.put("surefire-3.0.0-M5", "junit4", new Provider("com.lambdatest.surefire-3.0.0-M5", "junit4", ProviderVersion));
        customProviders.put("surefire-3.0.0-M5", "testng", new Provider("com.lambdatest.surefire-3.0.0-M5", "testng", ProviderVersion));
        customProviders.put("surefire-3.0.0-M5", "junit5", new Provider("com.lambdatest.surefire-3.0.0-M5", "junit5", ProviderVersion));

        customProviders.put("surefire-3.0.0-M7", "junit4", new Provider("com.lambdatest.surefire-3.0.0-M7", "junit4", ProviderVersion));
        customProviders.put("surefire-3.0.0-M7", "testng", new Provider("com.lambdatest.surefire-3.0.0-M7", "testng", ProviderVersion));
        customProviders.put("surefire-3.0.0-M7", "junit5", new Provider("com.lambdatest.surefire-3.0.0-M7", "junit5", ProviderVersion));

    }

    public static boolean lookupKnownProvider(String groupID, String artifactID) {
        if (knownProviders.size() == 0) {
            initKnownProviders();
        }
        return knownProviders.containsKey(groupID, artifactID);
    }

    public static Provider lookupCustomProvider(String surefireVersion, String testFramework) {
        if (customProviders.size() == 0) {
            initCustomProviders();
        }
        Object providerObject = customProviders.get(surefireVersion, testFramework);
        if (providerObject == null) {
            return null;
        }
        return (Provider) providerObject;
    }
}
