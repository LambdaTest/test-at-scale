package com.lambdatest.runner.api.util;

public class Utils {

    public static final String FILE_SEPARATOR = System.getProperty("file.separator");
    public static final String RepoID = System.getenv("REPO_ID");
    public static final String OrgID = System.getenv("ORG_ID");
    public static final String CommitID = System.getenv("COMMIT_ID");
    public static final String BuildID = System.getenv("BUILD_ID");
    public static final String TaskID = System.getenv("TASK_ID");

    public static final String BranchName = System.getenv("BRANCH_NAME");
    public static final String LocatorDelimiter = "##";

    public static final String TaskMode = System.getProperty("mode");


    public static String DiscoveryEndpoint = System.getenv("ENDPOINT_POST_TEST_LIST");

    public static String ExecutionEndpoint = System.getenv("ENDPOINT_POST_TEST_RESULTS");

    private static final String JAVA_SOURCE_FILE_EXTENSION = ".java";


    public enum Mode {
        discover, execute
    }

    public static boolean IsDiscoveryMode() {
        if (TaskMode != null) {
            return TaskMode.equals(Mode.discover.toString());
        }
        return false;
    }

    public static boolean IsExecutionMode() {
        if (TaskMode != null) {
            return TaskMode.equals(Mode.execute.toString());
        }
        return false;
    }

    public static String fullQualifiedNameToPath(String fqn) {
        if (FILE_SEPARATOR.equals("\\")) {
            return fqn.replace(".", "\\\\") + JAVA_SOURCE_FILE_EXTENSION;
        } else {
            return fqn.replace(".", FILE_SEPARATOR) + JAVA_SOURCE_FILE_EXTENSION;
        }
    }

    public static void validateEnv() throws RuntimeException {
        if (RepoID == null) {
            throw new RuntimeException("'REPO_ID' is not set in environment variables.");
        }
        if (OrgID == null) {
            throw new RuntimeException("'ORG_ID' is not set in environment variables.");
        }
        if (CommitID == null) {
            throw new RuntimeException("'COMMIT_ID' is not set in environment variables.");
        }
        if (BuildID == null) {
            throw new RuntimeException("'BUILD_ID' is not set in environment variables.");
        }
        if (TaskID == null) {
            throw new RuntimeException("'TASK_ID' is not set in environment variables.");
        }
        if (BranchName == null) {
            throw new RuntimeException("'BRANCH_NAME' is not set in environment variables.");
        }
    }

}
