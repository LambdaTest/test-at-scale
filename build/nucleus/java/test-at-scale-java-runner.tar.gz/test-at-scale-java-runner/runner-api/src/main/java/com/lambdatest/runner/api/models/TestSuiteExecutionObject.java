package com.lambdatest.runner.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;
import java.util.Optional;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestSuiteExecutionObject extends TestSuiteObject {
    Status status;
    long duration;

    String start_time;

    String end_time;

    @JsonIgnore
    private Integer totalExecutedTests = 0;

    @JsonIgnore
    private Integer totalTestsPassed = 0;

    @JsonIgnore
    private Integer totalTestsFailed = 0;

    @JsonIgnore
    private Integer totalTestsSkipped = 0;

    @Builder(builderMethodName = "childBuilder")
    public TestSuiteExecutionObject(String suiteID, String suiteName,
                                    String parentSuiteID, Integer totalTests,
                                    String locator, Status status,
                                    long duration, Integer totalExecutedTests,
                                    Integer totalTestsPassed, Integer totalTestsFailed,
                                    Integer totalTestsSkipped,
                                    String start_time, String end_time
    ) {
        super(suiteID, suiteName, parentSuiteID, totalTests, locator);
        this.status = status;
        this.duration = duration;
        this.totalExecutedTests = Optional.ofNullable(totalExecutedTests).orElse(this.totalExecutedTests);
        this.totalTestsPassed = Optional.ofNullable(totalTestsPassed).orElse(this.totalTestsPassed);
        this.totalTestsFailed = Optional.ofNullable(totalTestsFailed).orElse(this.totalTestsFailed);
        this.totalTestsSkipped = Optional.ofNullable(totalTestsSkipped).orElse(this.totalTestsSkipped);
        this.start_time = start_time;
        this.end_time = end_time;

    }

    /**
     * Find the winner status of the test suite based on the count
     * of tests.
     *
     * @return status
     */
    public Status winnerSuiteStatus() {
        if (this.totalTestsFailed > 0) {
            return Status.failed;
        }
        if (this.totalTestsSkipped == this.totalExecutedTests) {
            return Status.skipped;
        }
        return Status.passed;
    }
}
