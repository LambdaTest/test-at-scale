package com.lambdatest.runner.api.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lambdatest.runner.api.util.Utils;
import lombok.Builder;
import lombok.Data;

import java.util.Collection;

@Builder
@Data
public class DiscoveryObject {
    private Collection<TestObject> tests;

    private Collection<TestSuiteObject> testSuites;

    private final String repoID = Utils.RepoID;

    private final String commitID = Utils.CommitID;

    private final String buildID = Utils.BuildID;

    private final String taskID = Utils.TaskID;

    private final String orgID = Utils.OrgID;

    private final String branch = Utils.BranchName;

    private final  boolean executeAllTests=true;

    private static final ObjectMapper ObjectMapper = new ObjectMapper();



    public String buildRequestBody() {
        ObjectMapper.configOverride(Boolean.class).setFormat(JsonFormat.Value.forShape(JsonFormat.Shape.BOOLEAN));
        String strBody;
        try {
            strBody = ObjectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return strBody;
    }
}
