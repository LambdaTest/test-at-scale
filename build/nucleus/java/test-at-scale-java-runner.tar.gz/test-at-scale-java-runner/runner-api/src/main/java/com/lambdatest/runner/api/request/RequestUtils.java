package com.lambdatest.runner.api.request;

import com.lambdatest.runner.api.httpclient.Client;
import com.lambdatest.runner.api.logger.Logger;
import com.lambdatest.runner.api.models.*;

import java.util.Collection;
import java.util.Collections;

import static com.lambdatest.runner.api.util.Utils.DiscoveryEndpoint;
import static com.lambdatest.runner.api.util.Utils.ExecutionEndpoint;

public class RequestUtils {

    private final Logger logger;

    private final Client httpClient;

    public RequestUtils(Logger logger) {
        this.logger = logger;
        this.httpClient = new Client();
    }

    public void sendDiscoveryResult(Collection<TestObject> tests,
                                    Collection<TestSuiteObject> suites){
        DiscoveryObject testDiscovery = DiscoveryObject.builder().tests(tests).
                testSuites(suites).build();
        String requestBody = testDiscovery.buildRequestBody();
        if (DiscoveryEndpoint != null) {
            this.httpClient.sendPost(DiscoveryEndpoint, requestBody);
        }
        logger.info("Total tests discovered:" + tests.size());
        logger.info("Total suites discovered:" + suites.size());
        logger.info(requestBody + "\n");
    }

    public void sendExecutionResult(Collection<TestExecutionObject> testResults,
                                    Collection<TestSuiteExecutionObject> suiteResults){
        ExecutionResultObject.Result combinedResult = ExecutionResultObject.
                Result.builder().testResults(testResults).testSuiteResults(suiteResults)
                .build();

        ExecutionResultObject testExecutionResult = ExecutionResultObject.builder().results(
                Collections.singletonList(combinedResult)).build();
        String requestBody = testExecutionResult.buildRequestBody();

        if (ExecutionEndpoint != null) {
            httpClient.sendPost(ExecutionEndpoint, requestBody);
        }
        logger.info("Total tests executed:" + testResults.size());
        logger.info("Total suites executed:" + suiteResults.size());
        logger.info(requestBody + "\n");
    }
}
