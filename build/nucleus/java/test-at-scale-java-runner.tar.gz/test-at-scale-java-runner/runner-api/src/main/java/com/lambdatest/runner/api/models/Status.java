package com.lambdatest.runner.api.models;

public enum Status {
    passed,
    failed,
    skipped,
    blocklisted,
    quarantined,
}